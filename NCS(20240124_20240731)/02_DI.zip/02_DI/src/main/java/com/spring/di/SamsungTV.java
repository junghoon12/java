package com.spring.di;

public class SamsungTV implements TV {

	private SonySpeaker speaker;
	
	public SamsungTV() {
		
		System.out.println("==> SamsungTV 생성");
		
	}  // 기본 생성자
	
	public void powerOn() {
		System.out.println("SamsungTV ---> 전원 켜기 ");
	}
	
	public void powerOff() {
		System.out.println("SamsungTV ---> 전원 끄기");
	}
	
	public void volumeUp() {
		// System.out.println("SamsungTV ---> 소리 올리기");
		speaker = new SonySpeaker();
		speaker.volumeUp();
	}
	
	public void volumeDown() {
		// System.out.println("SamsungTV ---> 소리 내리기");
		speaker = new SonySpeaker();
		speaker.volumeDown();
	}
	
}
