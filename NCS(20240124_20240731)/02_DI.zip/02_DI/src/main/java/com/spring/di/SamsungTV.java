package com.spring.di;

public class SamsungTV implements TV {

	private Speaker speaker;
	private int price;
	
	public SamsungTV() {
		
		System.out.println("==> SamsungTV(1) 생성");
		
	}  // 기본 생성자
	
	public SamsungTV(Speaker speaker) {
		System.out.println("==> SamsungTV(2) 생성");
		this.speaker = speaker;
	}  // 인자 생성자
	
	
	public SamsungTV(Speaker speaker, int price) {
		System.out.println("==> SamsungTV(3) 생성");
		this.speaker = speaker;
		this.price = price;
	}  // 인자 생성자
	
	
	public void setSpeaker(Speaker speaker) {
		System.out.println("---> setSpeaker() 메서드 호출");
		this.speaker = speaker;
	}

	public void setPrice(int price) {
		System.out.println("---> setPrice() 메서드 호출");
		this.price = price;
	}

	public void powerOn() {
		System.out.println("SamsungTV ---> 전원 켜기 " + price);
	}
	
	public void powerOff() {
		System.out.println("SamsungTV ---> 전원 끄기");
	}
	
	public void volumeUp() {
		// System.out.println("SamsungTV ---> 소리 올리기");
		// speaker = new SonySpeaker();
		speaker.volumeUp();
	}
	
	public void volumeDown() {
		// System.out.println("SamsungTV ---> 소리 내리기");
		// speaker = new SonySpeaker();
		speaker.volumeDown();
	}
	
	
}
