package com.spring.di;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("tv")
public class LgTV implements TV {

	// @Autowired    // Type Injection
	// private AppleSpeaker speaker;
	
	
	public LgTV() {
		System.out.println("==> LgTV 생성");
	}  // 기본 생성자

	public void powerOn() {
		System.out.println("LgTV ---> 전원 켜기");
	}
	
	public void powerOff() {
		System.out.println("LgTV ---> 전원 끄기");
	}
	
	public void volumeUp() {
		// speaker.volumeUp();
		
		System.out.println("LgTV ---> 소리 올리기");
	}
	
	public void volumeDown() {
		// speaker.volumeDown();
		
		System.out.println("LgTV ---> 소리 내리기");
	}
	
}
