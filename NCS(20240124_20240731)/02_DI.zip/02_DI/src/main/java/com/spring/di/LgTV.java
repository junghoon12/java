package com.spring.di;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("tv")
public class LgTV implements TV {

	// 1. Speaker 타입의 객체가 반드시 메모리에 존재해야 함.
	// 2. Speaker 타입의 객체는 반드시 유일해야 함.
	//    현재는 Speaker타입의 두 개의 객체가 존재하기 때문에 오류 발생함.
	
	@Autowired    // Type Injection 이라고 함.
	private Speaker speaker;
	
	public LgTV() {
		
		System.out.println("==> LgTV 생성");
		
	}  // 기본 생성자
	
	public void powerOn() {
		System.out.println("LgTV ---> 전원 켜기");
	}
	
	public void powerOff() {
		System.out.println("LgTV ---> 전원 끄기");
	}
	
	public void volumeUp() {
		speaker.volumeUp();
	}
	
	public void volumeDown() {
		speaker.volumeDown();
	}
	
}



