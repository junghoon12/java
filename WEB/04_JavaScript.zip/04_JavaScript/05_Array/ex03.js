
let names = ['홍길동', '이순신', '유관순'];

console.log(`${names}`);

// unshift(요소) : 배열에 맨 앞(0번째 인덱스)에 추가하는 함수.
names.unshift('세종대왕');

console.log(`${names}`);

// shift() : 배열의 맨 처음 요소를 삭제하는 함수.
names.shift();

console.log(`${names}`);

// pop() : 배열의 맨 마지막 요소를 삭제하는 함수.
names.pop();

console.log(`${names}`);