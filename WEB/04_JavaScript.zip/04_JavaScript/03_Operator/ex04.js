// 단항(++, --) 연산자
let su1 = 10, su2 = 30;

console.log(`${--su1}`);  // 9

console.log(`${su2++}`);  // 30


// 삼항연산자.
// 형식) (조건식) ? 참인 경우 실행문 : 거짓인 경우 실행문;

let num = 27;

let res = (num > 20) ? "참" : false;


console.log(res);