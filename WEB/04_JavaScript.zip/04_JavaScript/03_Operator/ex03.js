// 논리연산자
// &&(논리곱)
// ||(논리합)
// !(부정)

let bol1 = true, bol2 = false, bol3 = true, bol4 = false;

console.log(`${bol1} && ${bol2} >>> ${bol1 && bol2}`);

console.log(`${bol1} && ${bol3} >>> ${bol1 && bol3}`);

console.log(`${bol2} || ${bol3} >>> ${bol2 || bol3}`);

console.log(`${bol2} }} ${bol4} >>> ${bol2 || bol4}`);


/*
  어떠한 값이 참이나 거짓을 의미하는 값이 아닌데도
  참이나 거짓을 의미하는 값처럼 사용되는 경우가 있음.
  이러한 값을 Truthy, Falsy 라고 함.
*/


// 3(true) && !0(true) ==> true
// !2(false) || true  ==> true
let su1 = !2 || 3 && !0;

console.log(su1);

let su2 = !-2 && (3 && !0);

console.log(su2);