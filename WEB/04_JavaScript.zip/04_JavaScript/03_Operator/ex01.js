// 산술연산자(+, -, *, /, %)

let num1 = 13, num2 = 3, result;

result = num1 + num2;
console.log(`${num1} + ${num2} = ${result}`);

result = num1 - num2;
console.log(`${num1} - ${num2} = ${result}`);

result = num1 * num2;
console.log(`${num1} * ${num2} = ${result}`);

result = num1 / num2;
console.log(`${num1} / ${num2} = ${result.toFixed(3)}`);

result = num1 % num2;
console.log(`${num1} % ${num2} = ${result}`);
