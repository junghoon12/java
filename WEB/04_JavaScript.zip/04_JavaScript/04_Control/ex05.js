/*
  난수를 발생시켜서 추첨을 통해 경품을 받게 만들어 보자.

  <요구사항>
  - 1 ~ 10 사이의 숫자를 랜덤하게 뽑아 보게 하자.
  - 3번 : 냉장고 당첨   /   5번 : 노트북 당첨   / 8번 : TV 당첨
  - 그 외의 번호는 "꽝"
  
  - 난수를 발생시키는 함수
    Math.floor(Math.random() * 마지막숫자) + 시작숫자
*/

let luckyNo = Math.floor(Math.random() * 10) + 1;

switch(luckyNo) {
    case 3 :
        console.log('냉장고에 당첨 되었습니다.');
        break;
    case 5 :
        console.log('노트북에 당첨 되었습니다.');
        break;
    case 8 :
        console.log('TV에 당첨 되었습니다.');
        break;
    default : 
        console.log('꽝!!!');
}