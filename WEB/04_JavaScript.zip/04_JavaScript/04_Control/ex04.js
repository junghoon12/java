let site = prompt("네이버, 다음, 구글 중 자주 이용하는 사이트는?");

let url;

switch(site) {

    case "네이버" : 
                url = "www.naver.com";
                break;
    case "다음" :
                url = "www.daum.net";
                break;
    case "구글" :
                url = "www.google.com";
                break;
    default :
                alert("보기 중에는 없는 사이트입니다.");
            
}

if(url) {
    // 실제 페이지로 이동이 진행되는 명령어.
    location.href="http://" + url;
}else {
    // 현재 페이지를 새로 고침하는 명령어.
    location.reload();
}