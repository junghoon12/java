let num = Number(prompt("정수 하나를 입력하세요"));

let oddSum = 0, evenSum = 0;

for(let i=1; i<=num; i++) {

    if(i % 2 === 1) {
        oddSum += i;
    }else {
        evenSum += i;
    } 
}

console.log(`입력받은 ${num} 까지 홀수의 합 >>> ${oddSum}`);
console.log(`입력받은 ${num} 까지 짝수의 합 >>> ${evenSum}`);