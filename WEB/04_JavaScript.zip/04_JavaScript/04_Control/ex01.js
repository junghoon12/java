/*
  자바스크립트에서 제어문의 종류
  1. 조건문
     - if문, if~else문, switch~case문

  2. 반복문
     - while 반복문, for 반복문
*/

let walk = Number(prompt("하루에 얼마나 걷나요?"));

if(walk >= 10000) {
    console.log('매우 좋은 습관을 가지고 있습니다.');
}