package com.mybatis.product;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mybatis.model.Category;
import com.mybatis.model.Product;
import com.mybatis.model.ProductDAO;

@Controller
public class ProductController {

	@Autowired
	private ProductDAO dao;
	
	
	@RequestMapping("/")
	public String index() {
		
		return "main";
	}
	
	
	@RequestMapping("product_list.go")
	public String list(Model model) {
		
		List<Product> list = this.dao.getProductList();
		
		model.addAttribute("List", list);
		
		return "product_list";
	}
	
	
	@RequestMapping("product_insert.go")
	public String insert(Model model) {
		
		// 제품 카테고리 코드 목록을 조회하여 제품 등록 폼페이지로 이동
		List<Category> list = this.dao.getCategoryList();
		
		model.addAttribute("cartList", list);
		
		return "product_insert";
		
	}
	
	@RequestMapping("product_insert_ok.go")
	public void insertOk(Product dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.insertProduct(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('제품 등록 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
	
	@RequestMapping("product_content.go")
	public String content(@RequestParam("pnum") int pnum, Model model) {
		
		Product dto = this.dao.getProductCont(pnum);
		
		model.addAttribute("Cont", dto);
		
		return "product_content";
	}
	
	
	@RequestMapping("product_modify.go")
	public String modify(@RequestParam("pnum") int pnum, Model model) {
		
		Product dto = this.dao.getProductCont(pnum);
		
		model.addAttribute("modify", dto);
		
		return "product_modify";
	}
	
	
	@RequestMapping("product_modify_ok.go")
	public void modifyOk(Product dto,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.updateProduct(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('제품 수정 성공!!!')");
			out.println("location.href='product_content.go?pnum="+dto.getPnum()+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 수정 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
			
	}
	
	
	@RequestMapping("product_delete.go")
	public void delete(@RequestParam("pnum") int pnum,
			HttpServletResponse response) throws IOException {
		
		int check = this.dao.deleteProduct(pnum);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			// 삭제된 제품번호보다 큰 번호에 대해서 다시 번호를 재작업 하는 메서드 호출
			this.dao.updateSequence(pnum);
			
			out.println("<script>");
			out.println("alert('제품 삭제 성공!!!')");
			out.println("location.href='product_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('제품 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}
	
	
	
	
	
}
