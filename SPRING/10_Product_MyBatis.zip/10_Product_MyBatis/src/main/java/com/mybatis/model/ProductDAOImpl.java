package com.mybatis.model;


import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

// 스프링에서 일반적으로 DAO 인터페이스를 구현한 클래스에는
// @Repository 애노테이션을 붙여서 사용함.

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;

	
	
	@Override
	public List<Product> getProductList() {

		return this.sqlSession.selectList("list");
	}

	@Override
	public int insertProduct(Product dto) {
		
		return this.sqlSession.insert("add", dto);
	}

	@Override
	public Product getProductCont(int pnum) {
		
		return this.sqlSession.selectOne("cont", pnum);
	}

	
	@Override
	public int updateProduct(Product dto) {
		
		return this.sqlSession.update("edit", dto);
	}

	@Override
	public int deleteProduct(int pnum) {
		
		return this.sqlSession.delete("del", pnum);
	}

	@Override
	public void updateSequence(int pnum) {
		
		this.sqlSession.update("seq", pnum);
	}

	@Override
	public List<Category> getCategoryList() {
		
		return this.sqlSession.selectList("cart");
	}

	
	
	

}
