package com.spring.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {

	// JDBC 관련 멤버 변수 선언
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = null;
	
	
	// 글 등록하는 메서드.
	public void insertBoard(BoardDTO dto) {
		
		
		try {
			con = JDBCUtil.getConnection();
			
			sql = "insert into board1 values("
					+ "(select nvl(max(seq), 0) + 1 from board1),"
					+ "?, ?, ?, sysdate, default)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getWriter());
			pstmt.setString(3, dto.getContent());
			
			pstmt.executeUpdate();
			
			System.out.println("==> JDBC 기반으로 insert() 메서드 기능 처리 완료!!!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			JDBCUtil.closeConn(pstmt, con);
		}
	
	}  // insertBoard() 메서드 end
	
	
	// board 테이블 전체 리스트를 조회하는 메서드.
	public List<BoardDTO> getBoardList() {
		
		List<BoardDTO> list = new ArrayList<BoardDTO>();
		
		
		try {
			con = JDBCUtil.getConnection();
			
			sql = "select * from board1 order by seq desc";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				BoardDTO dto = new BoardDTO();
				
				dto.setSeq(rs.getInt("seq"));
				dto.setTitle(rs.getString("title"));
				dto.setWriter(rs.getString("writer"));
				dto.setContent(rs.getString("content"));
				dto.setRegdate(rs.getString("regdate"));
				dto.setCnt(rs.getInt("cnt"));
				
				list.add(dto);
			}
			
			System.out.println("==> JDBC 기반으로 getBoardList() 메서드 기능 처리 완료!!!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			JDBCUtil.closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getBoardList() 메서드 end
	
}
