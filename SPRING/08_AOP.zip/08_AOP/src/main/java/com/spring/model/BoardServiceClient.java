package com.spring.model;

import java.util.List;

import org.springframework.context.support.GenericXmlApplicationContext;

public class BoardServiceClient {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container =
					new GenericXmlApplicationContext("business.xml");
		
		
		BoardService boards = (BoardService)container.getBean("boardService");
		
		BoardDTO dto = new BoardDTO();
		
		// dto.setSeq(0);
		dto.setTitle("스프링 AOP 테스트");
		dto.setWriter("관리자");
		dto.setContent("스프링 AOP 테스트 중입니다.....");
		
		boards.insertBoard(dto);   // 비지니스 로직
		
		List<BoardDTO> list = boards.getBoardList();  // 비지니스 로직
		
		for(BoardDTO board : list) {
			
			System.out.println("board >>> " + board.toString());
		}
		
		
		container.close();
		
		
	}

}
