package com.spring.model;

public class AfterThrowingAdvice {

	
	public void exceptionLog() {
		
		System.out.println("[예외 처리] 비지니스 로직 수행 중 예외 발생!!!");
		
	}
}
