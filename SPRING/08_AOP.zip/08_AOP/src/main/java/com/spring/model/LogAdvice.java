package com.spring.model;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect     // Aspect = Pointcut + Advice
public class LogAdvice {

	@Pointcut("execution(* com.spring.model..*Impl.*(..))")
	public void allPointcut() {   }   // body가 비어있는 메서드 하나를 선언함.
	
	
	@Before("allPointcut()")
	public void printLog() {
		
		System.out.println("<사전처리> 비지니스 로직 수행 전 동작");
		
	}
}
