package com.spring.model;

public class LogAdviceAdvanced {

	public void printLog() {
		
		System.out.println("<사전처리--Advanced> 비지니스 로직 수행 전 동작");
		
	}
}
