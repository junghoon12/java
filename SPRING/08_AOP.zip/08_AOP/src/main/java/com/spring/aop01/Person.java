package com.spring.aop01;

public interface Person {

	
	public void doSomething();
	
	
}
