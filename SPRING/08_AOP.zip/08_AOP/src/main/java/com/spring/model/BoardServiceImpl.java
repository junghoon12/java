package com.spring.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("boardService")
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDAO dao;
	
	
	
	@Override
	public void insertBoard(BoardDTO dto) {

		// 사전 처리 작업이 로그 출력 확인 작업.
		// 정책 변경 : <사전 처리>
		// System.out.println("[사전처리] 비지니스 로직 수행 전 동작");
		// LogAdvice advice = new LogAdvice();
		// advice.printLog();
		
		// 0번 글을 등록하려고 하면 예외를 발생시켜 보자.
		// if(dto.getSeq() == 0) {
			
		// 	throw new IllegalArgumentException();
		// }
		
		dao.insertBoard(dto);   // 핵심 로직

	}

	
	@Override
	public List<BoardDTO> getBoardList() {
		
		// 사전 처리 작업이 로그 출력 확인 작업.
		// System.out.println("[사전처리] 비지니스 로직 수행 전 동작");
		// LogAdvice advice = new LogAdvice();
		// advice.printLog();
		
		return dao.getBoardList();   // 핵심 로직
	}
	
	
	

}
