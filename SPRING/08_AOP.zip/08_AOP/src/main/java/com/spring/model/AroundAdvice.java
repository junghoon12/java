package com.spring.model;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

@Component
public class AroundAdvice {

	// Around로 등록되는 Advice는 리턴타입과 매개변수가 고정이 되어야 함.
	// 반환타입은 Object 타입, 매개변수는 ProceedingJoinPoint 타입이어야 함.
	public Object aroundLog(ProceedingJoinPoint jp) throws Throwable {
		
		Object obj = null;
		
		long startTime = System.currentTimeMillis();
		
		System.out.println("--- [Before Logic] ---");
		
		// 이 시점에 클라이언트가 호출한 비지니스 메서드가 실행된다.
		obj = jp.proceed();
		
		System.out.println("--- [After Logic] ---");
		
		long endTime = System.currentTimeMillis();
		
		System.out.println("비지니스 메서드에 소요된 시간 >>> " + (endTime - startTime) + "(ms)초");
		
		return obj;
	}
}
