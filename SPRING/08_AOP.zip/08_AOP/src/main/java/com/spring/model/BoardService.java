package com.spring.model;

import java.util.List;

public interface BoardService {

	
	void insertBoard(BoardDTO dto);
	
	List<BoardDTO> getBoardList();

	
}
