package com.spring.model;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AfterReturningAdvice {

	@Pointcut("execution(* com.spring.model..*Impl.*(..))")
	public void allPointcut() {   }   // body가 비어있는 메서드 하나를 선언함.
	
	@AfterReturning("allPointcut()")
	public void afterLog() {
		
		System.out.println("[사후 처리] 비지니스 로직 수행 후 동작");
	}
	
}
