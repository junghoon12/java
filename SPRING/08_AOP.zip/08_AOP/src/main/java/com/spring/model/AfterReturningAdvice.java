package com.spring.model;

public class AfterReturningAdvice {

	public void afterLog() {
		
		System.out.println("[사후 처리] 비지니스 로직 수행 후 동작");
	}
	
}
