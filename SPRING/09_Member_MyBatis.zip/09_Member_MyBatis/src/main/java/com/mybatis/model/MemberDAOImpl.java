package com.mybatis.model;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;
	
	
	
	@Override
	public List<Member> getMemberList() {
		
		return this.sqlSession.selectList("all");
	}

	@Override
	public int insertMember(Member dto) {
		
		return this.sqlSession.insert("add", dto);
	}

	@Override
	public Member getMember(int memno) {
		
		return this.sqlSession.selectOne("cont", memno);
	}

	@Override
	public int updateMember(Member dto) {
		
		return this.sqlSession.update("modify", dto);
	}

	@Override
	public int deleteMember(int memno) {
		
		return this.sqlSession.delete("del", memno);
	}

	@Override
	public void updateSequence(int memno) {
		
		this.sqlSession.update("seq", memno);
	}

	@Override
	public List<Member> searchMemberList(Map<String, String> map) {
		
		return this.sqlSession.selectList("search", map);
	}

}
