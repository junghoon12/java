package com.spring.di03;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("message.xml");
		
		Message message = (Message)container.getBean("message");
		
		message.outputMsg();
		
		
		container.close();
		

	}

}
