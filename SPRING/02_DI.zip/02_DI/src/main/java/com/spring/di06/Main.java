package com.spring.di06;

import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		GenericXmlApplicationContext container = 
				new GenericXmlApplicationContext("map.xml");
		
		MapTest test = (MapTest)container.getBean("test");
		
		test.output();
		
		
		container.close();

	}

}
