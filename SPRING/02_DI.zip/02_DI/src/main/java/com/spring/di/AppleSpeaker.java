package com.spring.di;

public class AppleSpeaker implements Speaker {

	public AppleSpeaker() {
		
		System.out.println("===> AppleSpeaker 객체 생성");
	}  // 기본 생성자.
	
	public void volumeUp() {
		System.out.println("AppleSpeaker --> 소리 올리기");
	}
	
	public void volumeDown() {
		System.out.println("AppleSpeaker --> 소리 내리기");
	}
}
