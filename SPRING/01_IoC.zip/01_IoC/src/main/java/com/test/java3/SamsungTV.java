package com.test.java3;

public class SamsungTV implements TV {
	
	private int price;

	public SamsungTV() {
		System.out.println("==> SamsungTV 객체 생성");
	}  // 기본 생성자
	
	public void initMethod() {
		
		System.out.println("==> 멤버변수 초기화 메서드 호출");
		
		this.price = 1500000;
	}
	
	public void powerOn() {
		System.out.println("SamsungTV --> 전원 켜기 " + price);
	}
	
	public void powerOff() {
		System.out.println("SamsungTV --> 전원 끄기");
	}
	
	public void volumeUp() {
		System.out.println("SamsungTV --> 소리 올리기");
	}
	
	public void volumeDown() {
		System.out.println("SamsungTV --> 소리 내리기");
	}
	
	
	
}
