package com.test.java1;

public class LgTV {

	public LgTV() {
		System.out.println("==> LgTV 객체 생성");
	}  // 기본 생성자
	
	public void turnOn() {
		System.out.println("LgTV --> 전원 켜기");
	}
	
	public void turnOff() {
		System.out.println("LgTV --> 전원 끄기");
	}
	
	public void soundUp() {
		System.out.println("LgTV --> 소리 올리기");
	}
	
	public void soundDown() {
		System.out.println("LgTV --> 소리 내리기");
	}
	
}
