package com.test.java3;

import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {

	public static void main(String[] args) {
		
		// 컨테이너를 생성한다.
		// BeanContainer container = new BeanContainer();
		// 스프링에서 제공하는 컨테이너를 생성해야 함.
		GenericXmlApplicationContext container =
				new GenericXmlApplicationContext("applicationContext.xml");
		
		
		// 컨테이너로부터 객체를 검색(Lookup)한다.
		TV tv = (TV)container.getBean("tv");
		
		tv.powerOn();           // 전원을 켜는 메서드 호출.
		
		tv.volumeUp();          // 볼륨을 올리는 메서드 호출.
		
		tv.volumeDown();        // 볼륨을 내리는 메서드 호출.
		
		tv.powerOff();          // 전원을 끄는 메서드 호출.
		
		// 컨테이너를 종료시키는 메서드.
		container.close();

	}

}
