package com.test.java3;


public class TestServlet {
	
	protected void 내맘대로() {
		// TODO Auto-generated method stub
		System.out.println("==> service() 메서드 호출");
	}

}
