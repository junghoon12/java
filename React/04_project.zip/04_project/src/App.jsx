
import './App.css';

import 'bootstrap/dist/css/bootstrap.css';
import ReactstrapPagination from './components/ReactstrapPagination';
import ReactstrapTable from './components/ReactstrapTable';

function App() {
  

  return (
    <div>
     <h2>Reactstrap Table 예제</h2> 
     <ReactstrapTable />
    </div>
  )
}

export default App
