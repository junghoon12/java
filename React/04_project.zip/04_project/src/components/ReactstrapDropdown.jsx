import { useState } from "react";
import { Dropdown, DropdownItem, DropdownMenu, DropdownToggle } from "reactstrap";

const ReactstrapDropdown = () => {

    const [dropdownOpen, setDropdownOpen] = useState(false);
    
    const toggle = () => {
        setDropdownOpen(prevState => !prevState);
    }

    const handleSelect = (value) => {
        alert(`선택한 항목 : ${value}`);
    }

    return (
        <Dropdown isOpen={dropdownOpen} toggle={toggle}>
            <DropdownToggle caret color="primary">
                선택하세요...
            </DropdownToggle>

            <DropdownMenu>
                <DropdownItem onClick={() => {handleSelect('항목 1')}}>항목1</DropdownItem>
                <DropdownItem onClick={() => {handleSelect('항목 2')}}>항목2</DropdownItem>
                <DropdownItem onClick={() => {handleSelect('항목 3')}}>항목3</DropdownItem>
            </DropdownMenu>
        </Dropdown>
    );
}

export default ReactstrapDropdown;