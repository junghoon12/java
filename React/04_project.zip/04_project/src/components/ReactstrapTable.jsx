import { Table } from "reactstrap";

const ReactstrapTable = () => {

    return (

        <Table striped hover>
           <thead>
              <th>Number</th> <th>Book Name</th> <th>Price</th>
           </thead>
           <tbody>
              <tr>
                <th scope="row">1</th>
                <td>React 예제</td>
                <td>25,000</td>
              </tr>

              <tr>
                <th scope="row">2</th>
                <td>React 소스</td>
                <td>15,000</td>
              </tr>
           </tbody>

        </Table>

    );

}

export default ReactstrapTable;