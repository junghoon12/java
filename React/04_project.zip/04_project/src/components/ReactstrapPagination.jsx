import { Pagination, PaginationItem, PaginationLink } from "reactstrap";

const ReactstrapPagination = () => {

    return (
        <div>
            <Pagination size="sm">
                <PaginationItem>
                    <PaginationLink previous />
                </PaginationItem>
                <PaginationItem>
                    <PaginationLink>1</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                    <PaginationLink>2</PaginationLink>
                </PaginationItem>
                <PaginationItem>
                    <PaginationLink last />
                </PaginationItem>
            </Pagination>

        </div>

    );

}

export default ReactstrapPagination;