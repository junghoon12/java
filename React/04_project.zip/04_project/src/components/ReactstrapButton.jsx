import { Button } from "reactstrap";

const ReactstrapButton = () => {

    return (
        <div>
            <Button color="primary">blue</Button>
            <Button color="info">teal</Button>
            <Button color="success">green</Button>
            <Button color="warning">yellow</Button>
            <Button color="danger">red</Button>
            <Button color="dark">gray</Button>
            <Button color="secondary">gray</Button>
            <Button color="light">white</Button>
        </div>
    );
}

export default ReactstrapButton;