import { useReducer } from "react";

// 상태를 실제로 변화시키는 변환기 역할.
function reducer(state, action) {
    switch(action.type) {
        case "INCREASE" :
            return state + action.data
        case "DECREASE" :
            return state - action.data
    }
}

const Exam = () => {

    // dispatch ==> 상태 변화가 있어야 한다는
    //              사실을 알리는, 발송하는 함수.
    // 첫번째 인자 : 실제로 상태를 변화시키는 함수.
    // 두번째 인자 : state에 들어갈 초기값.
    const [state, dispatch] = useReducer(reducer, 0);

    const onClickPlus = () => {
        // 상태 변화를 요청
        // 인수 : 상태가 어떻게 변화되길 원하는지
        // 인수는 객체 형태로 처리가 됨.
        dispatch({
            type : "INCREASE",
            data : 1,
        });
    }

    const onClickMinus = () => {
        dispatch({
            type : "DECREASE",
            data : 1,
        });
    }

    return (
        <div>
            <h1>{state}</h1>
            <button onClick={onClickPlus}>+</button>
            <button onClick={onClickMinus}>-</button>
        </div>
    )

}

export default Exam;