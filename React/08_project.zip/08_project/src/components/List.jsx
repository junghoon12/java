import "../css/list.css";
import TodoItem from "./TodoItem";
import { useState, useMemo } from "react";

const List = ({todos, onUpdate, onDelete}) => {

    const [search, setSearch] = useState("");

    const onChangeSearch = (e) => {
        setSearch(e.target.value);
    }

    // 함수를 하나 만들어 보자.
    const getFilteredData = () => {
        if(search === "") {
            return todos;  // 전체 리스트를 반환.
        }
        return todos.filter((todo) =>
            todo.content.toLowerCase().includes(search.toLowerCase()));
    }

    const filteredTodos = getFilteredData();

    // const getAnalyzedData = () => {
    //     console.log("getAnalyzedData 호출");
    //     const totalCount = todos.length;
    //     const doneCount = todos.filter((todo) => todo.isDone).length;
    //     const notDoneCount = totalCount - doneCount;

    //     return {
    //         totalCount,
    //         doneCount,
    //         notDoneCount
    //     }
    // }

    const {totalCount, doneCount, notDoneCount} = useMemo(() => {
        console.log("getAnalyzedData 호출");
        const totalCount = todos.length;
        const doneCount = todos.filter((todo) => todo.isDone).length;
        const notDoneCount = totalCount - doneCount;

        return {
            totalCount,
            doneCount,
            notDoneCount
        }
    },[todos]);

    return (
        <div className="list">
            <h4>Todo List🌱</h4>
            <div>
                <div>Total : {totalCount}</div>
                <div>Done : {doneCount}</div>
                <div>NotDone : {notDoneCount}</div>
            </div>
            <input 
                value={search}
                onChange={onChangeSearch}
                placeholder="검색어를 입력하세요" />
            <div className="todos_wrapper">
                {filteredTodos.map((todo) => {
                    return <TodoItem key={todo.id} {...todo} 
                                        onUpdate={onUpdate} 
                                        onDelete={onDelete} />
                })}
            </div>
        </div>
    )
}

export default List;