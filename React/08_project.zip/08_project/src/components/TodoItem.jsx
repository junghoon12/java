import "../css/todoitem.css";
import { memo } from "react";

const TodoItem = ({id, isDone, content, date, onUpdate, onDelete}) => {

    const onChangeCheck = () => {
        onUpdate(id);
    }

    const onDeleteButton = () => {
        onDelete(id);
    }


    return (
        <div className="todoitem">
            <input onChange={onChangeCheck} checked={isDone} type="checkbox" readOnly />
            <div className="content">{content}</div>
            <div className="date">{new Date(date).toLocaleDateString()}</div>
            <button onClick={onDeleteButton}>삭제</button>
        </div>
    )
}

export default memo(TodoItem,(prevProps, nextProps) => {
    // 반환값에 따라서 props가 변경되었는지, 변경이 안 되었는지를 판단.
    // true -> props 바뀌지 않음 ==> 리렌더링 X
    // false -> props 바뀜 ==> 리렌더링 O
    if(prevProps.id !== nextProps.id) return false;
    if(prevProps.isDone !== nextProps.isDone) return false;
    if(prevProps.content !== nextProps.content) return false;
    if(prevProps.date !== nextProps.date) return false;

    return true;
});