import './App.css'
import Blub from './components/Blub';
import Counter from './components/Counter';



function App() {

  return (
    <>
      <Blub />
      <Counter />
    </>
  );
}

export default App
