const Button = ({children, text, color = "black"}) => {

    // const {text, color} = props;
    const onClickButton = (e) => {
        console.log(e);
        console.log(text);
    }

    return <button 
                onClick = {onClickButton}
            style={{color : color}}>
        {text} - {color.toUpperCase()} {children} </button>

}



export default Button;