import { useState } from "react";

// 1. 리액트 훅은 함수형 컴포넌트 내부나
//    커스텀 훅 내부에서만 호출이 가능.
// const state = useState();  -- 오류가 발생.
function useInput() {

    const [input, setInput] = useState("");

    const onChange = (e) => {
        setInput(e.target.value);
    }

    return [input, onChange];
}



const HookExam = () => {
    
    // 구조 분해 할당을 이용함.
    const[input, onChange] = useInput();
    const[input1, onChange1] = useInput();

    return  <div>
                <div>
                    <input value={input} onChange={onChange} /> 
                </div>
                <div>
                    <input value={input1} onChange={onChange1} />
                </div>
        </div>

}

export default HookExam;