
import MemberList from "./components/MemberList";
import MemberDetail from "./components/MemberDetail";
import { Route, Routes } from "react-router-dom";

function App() {
  
  return (
    
      <div>
        {
          <Routes>
            <Route path="/" element={<MemberList />} />
            <Route path="/member/:memno" element={<MemberDetail />} />
          </Routes>
        }
      </div>
      
  )
}

export default App
