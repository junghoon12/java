
import MemberList from "./components/MemberList";
import MemberDetail from "./components/MemberDetail";
import { Route, Routes } from "react-router-dom";

function App() {
  
  return (
    
      <div>
        {
          <Routes>
            <Route path="/" element={<MemberList />} />
          </Routes>
        }
      </div>
      
  )
}

export default App
