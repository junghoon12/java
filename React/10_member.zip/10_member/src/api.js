import axios from "axios";

const BASE_URL = "http://localhost:8282/api/member";

export const getMembers = () => axios.get(`${BASE_URL}/list`);
export const getmember = (id) => axios.get(`${BASE_URL}/${id}`);