const MemberDetail = () => {

}

export default MemberDetail;