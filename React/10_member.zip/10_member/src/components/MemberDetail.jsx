import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getmember } from "../api";

const MemberDetail = () => {

    const {memno} = useParams();

    const [member, setMember] = useState(null);

    const navigate = useNavigate();

    useEffect(() => {
        getmember(memno)
        .then((res) => setMember(res.data))
        .catch((err) => console.error("상세조회 실패", err));
    }, [memno]);

    if(!member) return <div>Loading...</div>

    return (
        <div>
            <table border={1} width={450}>
                <tr>
                    <th colSpan={2} align="center">
                        {member.memname} 회원 상세 정보 페이지
                    </th>
                </tr>
                <tr>
                    <th>회원 No.</th>
                    <td>{member.memno}</td>
                </tr>
                <tr>
                    <th>회원 이름</th>
                    <td>{member.memname}</td>
                </tr>
                <tr>
                    <th>회원 아이디</th>
                    <td>{member.memid}</td>
                </tr>
                <tr>
                    <th>회원 나이</th>
                    <td>{member.age}</td>
                </tr>
                <tr>
                    <th>회원 마일리지</th>
                    <td>{member.mileage} 마일리지</td>
                </tr>
                <tr>
                    <th>회원 직업</th>
                    <td>{member.job}</td>
                </tr>
                <tr>
                    <th>회원 주소</th>
                    <td>{member.addr}</td>
                </tr>
                <tr>
                    <th>회원 등록일</th>
                    <td>{member.regdate}</td>
                </tr>
                <tr>
                    <td colSpan={2} align="center">
                        <button onClick={() => navigate("/")}>목록으로</button>
                    </td>
                </tr>
            </table>
        </div>
    )
}

export default MemberDetail;