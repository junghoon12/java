import "../css/todoitem.css";

const TodoItem = ({id, isDone, content, date, onUpdate, onDelete}) => {

    const onChangeCheck = () => {
        onUpdate(id);
    }

    const onDeleteButton = () => {
        onDelete(id);
    }


    return (
        <div className="todoitem">
            <input onChange={onChangeCheck} checked={isDone} type="checkbox" readOnly />
            <div className="content">{content}</div>
            <div className="date">{new Date(date).toLocaleDateString()}</div>
            <button onClick={onDeleteButton}>삭제</button>
        </div>
    )
}

export default TodoItem;