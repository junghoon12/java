package com.boot.react.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.react.model.Member;
import com.boot.react.model.MemberMapper;

@RestController
@RequestMapping("/api/member")
@CrossOrigin(origins = "*")     // react 접근 허용
public class MemberController {
	
	@Autowired
	private MemberMapper mapper;
	
	@GetMapping("/list")
	public List<Member> list() {
		
		return this.mapper.list();
	}

}
