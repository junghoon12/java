package com.example.thymeleaf;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BeginController {

	@RequestMapping("/{num}")
	public String abc(@PathVariable("num") int no, Model model) {
		
		int result = 0;
		
		for(int i=1; i<=no; i++) {
			
			result += i;
		}
		
		model.addAttribute("total", "total >>> " + result);
		
		return "index";
		
	}
	
	
	@RequestMapping("/message")
	public String bbb() {
		
		return "index_01";
	}
	
	
	@RequestMapping("/data")
	public String ccc(Model model) {
		
		model.addAttribute("msg", "방가방가 스프링부트");
		
		DataObject obj = new DataObject(100, "홍길동", "hong@gmail.com");
		
		model.addAttribute("Object", obj);
		
		return "index_02";
	}
	
	@RequestMapping("/data/{num}")
	public String ddd(@PathVariable("num") int no, Model model) {
		
		model.addAttribute("NO", no)
			 .addAttribute("check", no >= 0)
			 .addAttribute("trueVal", "양수입니다.")
			 .addAttribute("falseVal", "음수입니다.");
		
		return "index_03";
	}
	
	
	@RequestMapping("/data1/{num}")
	public String eee(@PathVariable("num") int no, Model model) {
		
		model.addAttribute("NO", no)
			 .addAttribute("check", no >= 0)
			 .addAttribute("trueVal", "양수입니다.")
			 .addAttribute("falseVal", "음수입니다.");
		
		return "index_04";
	}
	
	@RequestMapping("/score/{jumsu}")
	public String fff(@PathVariable("jumsu") double avg, Model model) {
		
		model.addAttribute("score", avg)
		     .addAttribute("hakjum", Math.floor(avg/10));
		
		return "index_05";
	}
	
	
	@RequestMapping("array")
	public String ggg(Model model) {
		
		List<String[]> data = new ArrayList<>();
		
		data.add(new String[] {"hong", "홍길동", "010-1111-1234", "hong@gmail.com"});
		data.add(new String[] {"leess", "이순신", "010-2222-2345", "leess@google.com"});
		data.add(new String[] {"yoo", "유관순", "010-3333-3456", "you@daum.net"});
		data.add(new String[] {"sejong", "세종대왕", "010-4444-4567", "sejong@naver.com"});
		data.add(new String[] {"shin", "신사임당", "010-5555-5678", "shin@naver.com"});
		
		model.addAttribute("List", data);
		
		return "index_06";
	}
	
	
	@RequestMapping("object")
	public String hhh(Model model) {
		
		List<DataObject> data = new ArrayList<DataObject>();
		
		data.add(new DataObject(0, "hong", "hong@gmail.com"));
		data.add(new DataObject(1, "leess", "leess@google.com"));
		data.add(new DataObject(2, "yoo", "you@daum.net"));
		data.add(new DataObject(3, "sejong", "sejong@naver.com"));
		data.add(new DataObject(4, "shin", "shin@naver.com"));
		
		model.addAttribute("Data", data);
		
		return "index_07";
	}
	
	
	@RequestMapping("obj")
	public String iii(Model model) {
		
		List<DataObject> data = new ArrayList<DataObject>();
		
		data.add(new DataObject(0, "hong", "hong@gmail.com"));
		data.add(new DataObject(1, "leess", "leess@google.com"));
		data.add(new DataObject(2, "yoo", "you@daum.net"));
		data.add(new DataObject(3, "sejong", "sejong@naver.com"));
		data.add(new DataObject(4, "shin", "shin@naver.com"));
		
		model.addAttribute("Data", data);
		
		return "index_08";
		
	}
	
	
	@RequestMapping("tax/{num}")
	public String jjj(@PathVariable("num") int tax, Model model) {
		
		model.addAttribute("Tax", tax);
		
		return "index_09";
		
	}
	
	
	@RequestMapping("include")
	public String kkk() {
		
		return "index_10";
	}
	
	
	@GetMapping("param")
	public String mmm(Model model) {
		
		model.addAttribute("name", "홍길동")
		     .addAttribute("email", "hong@naver.com");
		
		return "index_11";
	}
	
	
}
