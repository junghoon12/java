package com.json.board.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {

		
	List<Board> list();
	
	int add(Board bvo);
	
	void read(int bo);
	
	Board cont(int no);
	
	int edit(Board bvo);
	
	int del(int no);
	
	void seq(int no);
	
	
}
