package com.json.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.json.board.model.Board;
import com.json.board.model.BoardMapper;

@Controller
public class BoardController {

	@Autowired
	private BoardMapper mapper;
	
	@RequestMapping("/")
	public String main() {
		
		return "main";
	}
	
	
	@RequestMapping("board_list.go")
	@ResponseBody
	public List<Board> list() {
		
		List<Board> list = this.mapper.list();
		
		return list;
		
	}
	
	
	@PostMapping("board_write_ok.go")
	@ResponseBody
	public void insert(Board dto) {
		
		this.mapper.add(dto);
	}
	
	
	@PostMapping("board_edit_ok.go")
	@ResponseBody
	public String editOk(Board dto) {
		// 글 번호를 가지고 상세 정보를 조회한다.
		Board cont = this.mapper.cont(dto.getBoard_no());
		
		String res = null;
		
		// 비밀번호 맞는지 여부 확인.
		if(cont.getBoard_pwd().equals(dto.getBoard_pwd())) {
			
			int result = this.mapper.edit(dto);
			
			if(result > 0) {
				res = "OK";
			}else {
				res = "FAIL";
			}
		}else {
			res = "PASSWORD";
		}
		
		return res;
			
	}
	
}
