package com.boot.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.board.model.Board;
import com.boot.board.model.BoardMapper;
import com.boot.board.model.Page;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class BoardController {

	@Autowired
	private BoardMapper mapper;
	
	// 한 페이지당 보여질 게시물의 수.
	private final int rowsize = 3;
	
	// DB 상의 전체 게시물의 수.
	private int totalRecord = 0;
	
	@GetMapping("/")
	public String home() {
		
		return "main";
	}
	
	@GetMapping("board_list.go")
	public String list(@RequestParam(value = "page", defaultValue = "1") int page,
							Model model) {
		
		// DB 상의 전체 게시물의 수를 확인하는 메서드 호출.
		totalRecord = this.mapper.count();
		
		Page pdto = new Page(page, rowsize, totalRecord);
		
		// 현재 페이지에 해당하는 게시물을 가져오는 메서드 호출.
		List<Board> list = this.mapper.list(pdto);
		
		model.addAttribute("List", list)
			 .addAttribute("Paging", pdto);
		
		return "board_list";
	}
	
	
	@GetMapping("board_write.go") 
	public String writeForm() { 
		
		return "board_write"; 
	}
	 

    @PostMapping("board_write_ok.go")
     public void writeOk(Board dto, HttpServletResponse response) throws IOException {
    	// 글쓰기 작업 처리
        System.out.println("Board >>> " + dto);
        
        int check = this.mapper.add(dto);
        
        response.setContentType("text/html; charset=UTF-8");
        
        PrintWriter out = response.getWriter();
        
    	if(check > 0) {
    		out.println("<script>");
    		out.println("alert('게시글 추가 성공!!!')");
    		out.println("location.href='board_list.go'");
    		out.println("</script>");
    	}else {
    		out.println("<script>");
    		out.println("alert('게시글 추가 실패~~~')");
    		out.println("history.back()");
    		out.println("</script>");
    	}
    }
    
    
    @GetMapping("board_content.go")
    public String cont(@RequestParam("no") int no, 
    		@RequestParam("page") int nowPage, Model model) {
    	
    	// 게시글의 조회수를 하나 증가시켜 주는 메서드 호출
    	this.mapper.read(no);
    	
    	// 게시글의 상세 내역을 조회하는 메서드 호출.
    	Board content = this.mapper.cont(no);
    	
    	model.addAttribute("Content", content)
    	      .addAttribute("page", nowPage);
    	
    	return "board_content";
    }
    
    @GetMapping("board_modify.go")
    public String modify(@RequestParam("no") int no, 
    		@RequestParam("page") int nowPage, Model model) {
    	
    	System.out.println("no >>> " + no);
    	// 게시글의 상세 내역을 조회하는 메서드 호출.
    	Board content = this.mapper.cont(no);
    	
    	model.addAttribute("Modify", content)
    	     .addAttribute("page", nowPage);
    	
    	return "board_modify";
    }
    
    @PostMapping("board_modify_ok.go")
    public void modifyOk(Board dto,
    		@RequestParam("db_pwd") String db_pwd,
    		@RequestParam("page") int nowPage,
    		HttpServletResponse response) throws IOException {
    	
    	response.setContentType("text/html; charset=UTF-8");
    	
    	PrintWriter out = response.getWriter();
    	
    	if(db_pwd.equals(dto.getBoard_pwd())) {
    		
    		int result = this.mapper.edit(dto);
    		
    		if(result > 0) {
    			out.println("<script>");
    			out.println("alert('게시글 수정 성공.!!!')");
    			out.println("location.href='board_content.go?no="+dto.getBoard_no()+"&page="+nowPage+"'");
    			out.println("</script>");
    		}else {
    			out.println("<script>");
    			out.println("alert('게시글 수정 실패~~~')");
    			out.println("history.back()");
    			out.println("</script>");
    		}
    	}else {
    		out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.back()");
			out.println("</script>");
    	}
    	
    }
    
    @GetMapping("board_delete.go")
    public String delete(@RequestParam("no") int no, 
    		@RequestParam("page") int nowPage, Model model) {
    	
    	model.addAttribute("No", no)
    	     .addAttribute("page", nowPage);
    	
    	return "board_delete";
    }
    
    @PostMapping("board_delete_ok.go")
    public void deleteOk(@RequestParam("board_no") int no,
    		@RequestParam("board_pwd") String pwd,
    		@RequestParam("page") int nowPage,
    		HttpServletResponse response) throws IOException {
    	
    	response.setContentType("text/html; charset=UTF-8");
    	
    	PrintWriter out = response.getWriter();
    	
    	Board content = this.mapper.cont(no);
    	
    	if(pwd.equals(content.getBoard_pwd())) {
    		
    		int result = this.mapper.del(no);
    		
    		if(result > 0) {
    			this.mapper.seq(no);
    			
    			out.println("<script>");
    			out.println("alert('게시글 삭제 성공.!!!')");
    			out.println("location.href='board_list.go?page="+nowPage+"'");
    			out.println("</script>");
    		}else {
    			out.println("<script>");
    			out.println("alert('게시글 삭제 실패~~~')");
    			out.println("history.back()");
    			out.println("</script>");
    		}
    	}else {
    		out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 다시 확인해 주세요.~~')");
			out.println("history.back()");
			out.println("</script>");
    	}
    	
    }
    
    
    @RequestMapping("board_search.go")
    public String search(@RequestParam("field") String field,
    		@RequestParam("keyword") String keyword, 
    		@RequestParam(value = "page", defaultValue = "1") int page, 
    		Model model) {
    	
    	
    	// 검색 페이징 작업
    	
    	// 검색 분류와 검색어에 해당하는 게시글의 수를 DB에서 확인하는 작업.
    	Map<String, String> map = new HashMap<String, String>();
    	
    	map.put("field", field);
    	map.put("keyword", keyword);
    	
    	totalRecord = this.mapper.scount(map);
    	
    	Page pdto = new Page(page, rowsize, totalRecord, field, keyword);
    	
    	// 검색 시 한 페이지당 보여질 게시물의 수만큼
    	// 검색한 게시물을 List로 가져오는 메서드 호출.
    	List<Board> searchList = this.mapper.search(pdto);
    	
    	
    	model.addAttribute("SearchList", searchList)
    		 .addAttribute("Paging", pdto);
    	
    	return "board_search_list";
    	
    }
	
	
}
