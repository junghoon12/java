package com.boot.board1.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.boot.board1.model.Board;
import com.boot.board1.model.BoardMapper;
import com.boot.board1.model.Page;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class BoardController {

	@Autowired
	private BoardMapper mapper;
	
	// 한 페이지당 보여질 게시물의 수.
	private final int rowsize = 3;
	
	// DB 상의 전체 게시물의 수.
	private int totalRecord = 0;
	
	
	@GetMapping("/")
	public String main() {
		
		return "main";
	}
	
	@GetMapping("board_list.go")
	public String list(@RequestParam(value = "page", defaultValue = "1") int page,
								Model model) {
		
		// DB 상의 전체 게시물의 수를 조회하는 메서드 호출.
		totalRecord = this.mapper.count();
		
		Page pdto = new Page(page, rowsize, totalRecord);
		
		// 현재 페ㅣ지에 해당하는 게시글 목록을 가져오는 메서드 호출.
		List<Board> list = this.mapper.list(pdto);
		
		model.addAttribute("List", list)
		     .addAttribute("Paging", pdto);
		
		return "board_list";
		
	}
	
	
	@GetMapping("board_write.go")
	public String write() {
		
		return "board_write";
	}
	
	
	@PostMapping("board_write_ok.go")
	public void writeOk(Board dto,
				HttpServletResponse response) throws IOException {
		
		int res = this.mapper.add(dto);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			out.println("<script>");
			out.println("alert('게시글 등록 성공!!!')");
			out.println("location.href='board_list.go'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('게시글 등록 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@GetMapping("board_content.go")
	public String cont(@RequestParam("no") int no,
					@RequestParam("page") int nowPage,
					Model model) {
		
		// 조회 수를 증가시켜 주는 메서드 호출
		this.mapper.read(no);
		
		// 게시글 번호에 해당하는 상세 내역을 조회하는 메서드 호출
		Board cont = this.mapper.cont(no);
		
		model.addAttribute("Content", cont)
			 .addAttribute("Page", nowPage);
		
		return "board_content";
		
	}
	
	
	@GetMapping("board_modify.go")
	public String modify(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		Board cont = this.mapper.cont(no);
		
		model.addAttribute("Modify", cont)
		     .addAttribute("Page", nowPage);
		
		return "board_modify";
		
	}
	
	
	@PostMapping("board_modify_ok.go")
	public void modifyOk(Board dto,
			@RequestParam("db_pwd") String db_pwd,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getBoard_pwd())) {
			
			int res = this.mapper.edit(dto);
			
			if(res > 0) {
				out.println("<script>");
				out.println("alert('게시글 수정 성공!!!')");
				out.println("location.href='board_content.go?no="+dto.getBoard_no()+"&page="+nowPage+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('게시글 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {  // 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세여~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@GetMapping("board_delete.go")
	public String delete(@RequestParam("no") int no,
			@RequestParam("page") int nowPage, Model model) {
		
		Board cont = this.mapper.cont(no);
		
		model.addAttribute("Delete", cont)
		     .addAttribute("Page", nowPage);
		
		return "board_delete";
		
	}
	
	
	@PostMapping("board_delete_ok.go")
	public void deleteOk(Board dto,
			@RequestParam("db_pwd") String db_pwd,
			@RequestParam("page") int nowPage,
			HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(db_pwd.equals(dto.getBoard_pwd())) {
			
			int res = this.mapper.del(dto.getBoard_no());
			
			if(res > 0) {
				
				this.mapper.seq(dto.getBoard_no());
				
				out.println("<script>");
				out.println("alert('게시글 삭제 성공!!!')");
				out.println("location.href='board_list.go?page="+nowPage+"'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {  // 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세여~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
	}
	
	
	@RequestMapping("board_search.go")
	public String search(@RequestParam("field") String field,
			@RequestParam("keyword") String keyword,
			@RequestParam(value = "page", defaultValue = "1") int page, Model model) {
		
		// 검색 페이징 처리 작업
		
		// 검색분류와 검색어에 해당하는 게시글의 수를 DB에서 확인하는 작업.
		Map<String, String> map = 
						new HashMap<String, String>();
		
		map.put("Field", field);
		map.put("Keyword", keyword);
		
		totalRecord = this.mapper.scount(map);
		
		Page pDto = 
				new Page(page, rowsize, totalRecord, field, keyword);
		
		// 검색 시 한 페이지당 보여질 게시물의 수만큼
		// 검색한 게시물을 List로 가져오는 메서드 호출.
		List<Board> searchList = this.mapper.search(pDto);
		
		model.addAttribute("searchPageList", searchList)
			 .addAttribute("Paging", pDto);
		
		return "board_search_list";
		
	}
	
	
}
