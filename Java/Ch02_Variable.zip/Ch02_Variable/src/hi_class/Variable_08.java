package hi_class;

public class Variable_08 {

	public static void main(String[] args) {
		
		// 변수 선언 및 변수 초기화
		int su1 = 47, su2 = 88;
		
		System.out.println("바꾸기 전.....");
		
		System.out.println("su1 >>> " + su1);
		
		System.out.println("su2 >>> " + su2);
		
		// 방법 1
		// int temp = su1;
		
		// su1 = su2;
		
		// su2 = temp;
		
		// 방법 2
		int temp = su2;
		
		su2 = su1;
		
		su1 = temp;
		
		
		System.out.println("바꾼 후.....");
		
		System.out.println("su1 >>> " + su1);
		
		System.out.println("su2 >>> " + su2);
		
		

	}

}
