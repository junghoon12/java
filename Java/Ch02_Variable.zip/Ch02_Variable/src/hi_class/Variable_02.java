package hi_class;

public class Variable_02 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// int num;
		
		// 2. 변수 초기화
		// num = 130;
		
		// 1 + 2 : 변수 선언 및 변수 초기화
		int num = 130;
		
		int num1 = num;
		
		// 3. 변수 출력
		System.out.println("num >>> " + num);
		
		System.out.println("num1 >>> " + num1);
		

	}

}
