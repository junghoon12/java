package hi_class;

import javax.swing.JOptionPane;

public class Operator_02 {

	public static void main(String[] args) {
		
		// 키보드로 데이터를 입력받는 방법 - 첫번째
		int su1 = 
				Integer.parseInt(JOptionPane.showInputDialog("첫번째 정수를 입력하세요"));
		
		int su2 = 
				Integer.parseInt(JOptionPane.showInputDialog("두번째 정수를 입력하세요"));
		
		// 덧셈연산
		System.out.println("덧셈연산 결과 >>> " + (su1 + su2));
		System.out.println();
		
		// 뺄셈연산
		System.out.println("뺄셈연산 결과 >>> " + (su1 - su2));
		System.out.println();
		
		// 곱셈연산
		System.out.println("곱셈연산 결과 >>> " + (su1 * su2));
		System.out.println();
		
		// 나눗셈연산
		System.out.println("나눗셈연산 결과 >>> " + (su1 / su2));
		System.out.println();
		
		// 나머지연산
		System.out.println("나머지연산 결과 >>> " + (su1 % su2));
		System.out.println();
		

	}

}
