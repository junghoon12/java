package hi_class;

/*
 * 4. 단항연산자 / 삼항연산자
 *    - 단항연산자 : 1개의 항을 대상으로 연산을 수행.
 *    - 삼항연산자 : 3개의 항을 대상으로 연산을 수행.
 */

public class Operator_07 {

	public static void main(String[] args) {
		
		// 단항연산자(++, --)
		int su1 = 10, su2 = 10;
		
		System.out.println("su1++ >>> " + su1++);
		System.out.println(su1);
		
		System.out.println("++su2 >>> " + ++su2);
		System.out.println(su2);
		
		/*
		 * 단항연산자(++, --)
		 * - 전위연산자 : 단항연산자가 변수명 앞에 오는 경우(++su2).
		 *              변수의 값을 하나 증가 또는 감소 시킨 후에 처리.
		 * - 후위연산자 : 단항연산자가 변수명 뒤에 오는 경우(su1++).
		 *              변수를 처리한 후 값을 하나 증가 또는 감소.
		 */
		
		int su3 = 10, su4 = 20;
		
		System.out.println(++su3 + su4++);   // 11 + 20 ==> 31
		System.out.println();
		
		// (12 % 3) ==> 0   /   (12 * 22) ==> 264
		System.out.println((++su3 % 3) + (su3 * ++su4));  // 0 + 264 ==> 265
		
		
		/*
		 * 삼항연산자
		 * 
		 * 형식) (조건) ? 수식1 : 수식2;
		 * 
		 *              ==> 수식1 : 조건이 참인 경우 실행 문장. 
		 *              ==> 수식2 : 조건이 거짓인 경우 실행 문장.
		 *              
		 * - 간단하게 조건문을 대신하여 사용할 수 있는 연산자.
		 */
		
		int num1 = 17, num2 = 33;
		
		String res = (num1 >= num2) ? "num1 값이 크다" : "num2 값이 크다";
		
		System.out.println(res);
		
		
	}

}
