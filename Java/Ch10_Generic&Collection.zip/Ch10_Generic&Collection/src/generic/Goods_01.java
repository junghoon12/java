package generic;

public class Goods_01 {

	public static void main(String[] args) {
		
		// Goods1 객체를 이용하여 Apple 객체를 생성.
		Goods1 goods1 = new Goods1();
		
		Apple apple = new Apple();
		
		goods1.setApple(apple);
		
		Apple apple2 = goods1.getApple();
		
		apple2.output();
		
		System.out.println();
		
		// Goods2 객체를 이용하여 Pencil 객체를 생성.
		Goods2 goods2 = new Goods2();
		
		// Pencil 객체 타입만 매개변수로 사용이 가능.
		goods2.setPencil(new Pencil());
		
		Pencil pencil = goods2.getPencil();
		
		pencil.output();
		

	}

}
