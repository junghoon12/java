package generic;

public class Apple {

	void output() {
		
		System.out.println("사과입니다.~~~~");
	}
	
}
