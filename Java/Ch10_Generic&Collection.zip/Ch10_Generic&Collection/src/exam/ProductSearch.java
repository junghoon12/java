package exam;

import javax.swing.JOptionPane;

public class ProductSearch {

	public static void main(String[] args) {
		
		String pName = 
			JOptionPane.showInputDialog("검색할 상품명을 입력하세요.");
		
		ProductSearchData psd = new ProductSearchData();
		
		String pInfo = psd.search(pName);
		
		try {
			
			pInfo.length();   // 예외가 발생할 가능성이 있는 코드.
			
			JOptionPane.showMessageDialog(null, pInfo);
			
		}catch(Exception e) {
			
			JOptionPane.showMessageDialog(null, "해당 상품이 없습니다.");
			
			e.printStackTrace();
		}
		
	}

}
