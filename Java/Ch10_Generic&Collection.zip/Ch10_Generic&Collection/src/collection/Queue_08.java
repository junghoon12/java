package collection;

import java.util.LinkedList;
import java.util.Queue;

/*
 * Queue 자료 구조
 * - Queue는 인터페이스임. 따라서 자식 클래스를 객체를 생성하여 사용함.
 * - 대표적인 자식 클래스는 LinkedList 클래스임.
 * - 특징 : 선입선출(FIFO : First In Fisrt Out) 구조임.
 */

public class Queue_08 {

	public static void main(String[] args) {
		
		Queue<Integer> queue = new LinkedList<Integer>();
		
		// 1. add() : 큐에 저장하는 메서드.
		//            큐에서 예외처리 기능이 미포함된 메서드.
		queue.add(3);
		queue.add(4);
		queue.add(5);
		
		// element() : 큐에 가장 먼저 입력된 데이터를 출력하는 메서드.
		System.out.println(queue.element());
		
		System.out.println();
		
		// remove() : 큐에 가장 먼저 입력된 데이터를 출력 후 제거하는 메서드.
		
		System.out.println(queue.remove());  // 3
		
		System.out.println(queue.remove());  // 4
		
		System.out.println(queue.remove());  // 5
		
		// 실제로는 큐에 저장된 데이터는 없음. ==> 예외가 발생.
		// System.out.println(queue.remove());
		
		System.out.println();
		
		Queue<Integer> queue2 = new LinkedList<Integer>();
		
		// 1. offer() : 큐에 저장하는 메서드.
		//              큐에서 예외처리 기능이 포함된 메서드.
		queue2.add(3);
		queue2.add(4);
		queue2.add(5);
		
		// element() : 큐에 가장 먼저 입력된 데이터를 출력하는 메서드.
		System.out.println(queue2.element());
		
		// poll() : 큐에 가장 먼저 입력된 데이터를 출력한 후 제거하는 메서드.
		System.out.println(queue2.poll());  // 3
		
		System.out.println(queue2.poll());  // 4
		
		System.out.println(queue2.poll());  // 5
		
		// 실제 큐에 저정된 데이터는 없음.
		System.out.println(queue2.poll());  // 데이터가 없음.
		

	}

}
