package hi_class;

// 구현된 메서드의 약식 표현.

interface SuperA {
	
	// 반환타입(X), 매개변수(X)
	void method1();
}

interface SuperB {
	
	// 반환타입(X), 매개변수(O)
	void method2(int su);
}

interface SuperC {
	
	// 반환타입(O), 매개변수(X)
	int method3();
}

interface SuperD {
	
	// 반환타입(O), 매개변수(O)
	double method4(int su1, double su2);
}



public class Lambda_02 {

	public static void main(String[] args) {
		
		// 1. 일반적으로 객체 생성.
		//    ==> 반환타입(X), 매개변수(X)
		SuperA a = new SuperA() {
			
			@Override
			public void method1() {
				
				System.out.println("일반적인 객체 생성 ==> 반환타입(X), 매개변수(X) 메서드~~~");
				
			}
		};
		
		a.method1();
		
		System.out.println();
		
		// 1-2. 람다식으로 표현하는 방법.
		SuperA a2 = () -> {
			System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드~~~");
		};
		
		a2.method1();
		System.out.println();
		
		SuperA a3 = () -> System.out.println("람다식 ==> 반환타입(X), 매개변수(X) 메서드~~~");
		
		a3.method1();
		System.out.println();
		
		// 2-1. 람다식으로 표현하는 방법.
		SuperB b = (int su) -> {
			System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드~~~ / su >>> " + su);
		};
		
		b.method2(88);
		System.out.println();
		
		SuperB b1 = (su) -> {
			System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드~~~ / su >>> " + su);
		};
		
		b1.method2(27);
		System.out.println();
		
		SuperB b2 = su -> {
			System.out.println("람다식 ==> 반환타입(X), 매개변수(O) 메서드~~~ / su >>> " + su);
		};
		
		b2.method2(53);
		System.out.println();
		
		// 3-1. 람다식으로 표현하는 방법 ==> 반환타입(O), 매개변수(X)
		SuperC c1 = () -> {
			return 76;
		};
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(X) 메서드 >>> " + c1.method3());
		
		System.out.println();
		
		
		// 메서드 호출 시 return 문장이 한 문장이면 return 키워드와 { } (중괄호) 생략 가능.
		SuperC c2 = () -> 23;
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(X) 메서드 >>> " + c2.method3());
		
		System.out.println();
		
		
		SuperD d1 = (int su1, double su2) -> {
			
			return su1 + su2;
		};
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드 >>> " + d1.method4(40, 128));
		
		System.out.println();
		
		
		SuperD d2 = (su1, su2) -> su1 + su2;
		
		System.out.println("람다식 ==> 반환타입(O), 매개변수(O) 메서드 >>> " + d2.method4(122, 130));
		
		System.out.println();

	}

}
