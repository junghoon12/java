package hi_class;

public class Thread_06 {

	public static void main(String[] args) {
		
		new Thread() {
			
			@Override
			public void run() {
				
				for(int i=1; i<=100; i++) {
					
					System.out.println("number >>> " + i);
				}
			}
			
		}.start();
		
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				for(char c='A'; c<='Z'; c++) {
					
					System.out.println("alpha >>> " + c);
				}
				
			}
			
		}).start();

	}

}
