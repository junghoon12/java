package abstracts;

public class Sub extends Super {

	@Override
	void output() {
		
		System.out.println("추상메서드 재정의 했어요~~~");
		
	}
	

}
