package exam;

public class Employee {

	// 멤버변수
	String name;        // 이름

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	// 급여를 계산하는 메서드.
	// 자식클래스에서 재정의 할 메서드.
	int getPays() {
		
		return 0;
	}
	
	
}
