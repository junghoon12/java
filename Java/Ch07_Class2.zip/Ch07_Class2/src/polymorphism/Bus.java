package polymorphism;

public class Bus implements Vehicle {

	@Override
	public void run() {
		
		System.out.println("버스가 전용차로로 달립니다.~~~");

	}

}
