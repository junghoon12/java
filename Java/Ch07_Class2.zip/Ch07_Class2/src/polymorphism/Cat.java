package polymorphism;

public class Cat implements Animal {

	@Override
	public void sound() {
		
		System.out.println("야옹야옹~~~");

	}
	
	void output() {
		
		System.out.println("출력용 메서드입니다.~~~");
	}
	

}
