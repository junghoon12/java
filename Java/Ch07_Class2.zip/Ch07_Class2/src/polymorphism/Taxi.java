package polymorphism;

public class Taxi implements Vehicle {

	@Override
	public void run() {
		
		System.out.println("총알 택시가 달립니다.~~~");

	}

}
