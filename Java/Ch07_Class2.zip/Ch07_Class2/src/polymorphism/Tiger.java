package polymorphism;

public class Tiger extends Animal2 {

	public void sound() {
		
		System.out.println("어흥어흥~~~");
	}

}
