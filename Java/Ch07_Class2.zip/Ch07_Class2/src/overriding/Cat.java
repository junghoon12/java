package overriding;

public class Cat extends Animal {

	@Override
	void sound() {
		
		System.out.println("야옹야옹~~~");
		
	}
}
