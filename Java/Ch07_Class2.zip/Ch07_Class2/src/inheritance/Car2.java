package inheritance;

public class Car2 {

	int cc;
	int door;
	String color = "검정색";
	
}
