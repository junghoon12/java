package inheritance;


public class Sonata extends Car {

	// Car 부모클래스에서 상속받은 멤버 생략.
	// int cc;
	// int door;
	String model;        // 차량 모델명
	
	void getCarInfo() {
		
		System.out.println("모델명 >>> " + model);
		System.out.println("배기량 >>> " + cc);
		System.out.println("차량 문 수 >>> " + door);
		
	}  // getCarInfo() 메서드 end

}
