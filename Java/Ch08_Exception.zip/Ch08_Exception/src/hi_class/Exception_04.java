package hi_class;

/*
 * 예외 처리
 * - 실행하는 단계에서 발생한 오류(예외)를
 *   프로그램적으로 처리한다는 의미.
 * - 개발자가 작성한 프로그램의 실행 중에 예외가
 *   발생하면 이에 대응하는 것을 말함.
 *   
 * - 관련 키워드
 *   1. try ~ catch ~ finally 블럭
 *   2. throws 키워드
 *   
 * - 자바의 예외 클래스
 *   * ArithmeticException : 정수를 0으로 나눌 때 발생.
 *   * NullPointerException : null 레퍼런스를 참조할 때 발생.
 *   * ClassCastException : 변환할 수 없는 타입으로 객체를 
 *                          변환할 때 발생.
 *   * OutOfMemoryError : 메모리가 부족한 경우 발생.
 *   * ArrayIndexOutOfBoundsException : 배열의 범위를 벗어난
 *                                      접근 시 발생.
 *   * IllegalArgumentException : 잘못된 인자 전달 시 발생.
 *   * IOException : 입출력 동작 실패 또는 인터럽트 시 발생.
 *   * NumberFormatException : 문자열이 나타내는 숫자와 일치하지
 *                             않는 타입의 숫자로 변환 시 발생.
 *   * InputMismatchException : Scanner 클래스의 nextInt()를
 *                              호출하여 정수로 입력받고자 하였지만,
 *                              사용자가 문자를 입력한 경우
 */

/*
 * 1. try ~ catch ~ finally  블럭
 * 
 *    형식)
 *    		try {
 *    			예외가 발생할 가능성이 있는 코드;
 *    		}catch(예외클래스 참조변수) {
 *    			예외가 발생한 경우 실행되는 코드;
 *    			참조변수 : 예외와 관련된 정보를 넘겨받는 변수.
 *    		}finally {
 *    			// 생략이 가능함.
 *    			예외와 상관없이 실행되어야 하는 코드;
 *    		}
 */

public class Exception_04 {

	public static void main(String[] args) {
		
		System.out.println("프로그램 시작");
		
		int num1 = 10, num2 = 0;
		
		int result = 0;
		
		try {
			
			result = num1 / num2;  // 예외가 발생할 가능성이 있는 코드
			
		}catch(Exception e) {
			
			System.out.println("0으로 나눈 예외 발생~~~");
			
			System.out.println("예외정보 >>> " + e);
		}
		
		
		System.out.println("result >>> " + result);
		
		
		System.out.println("프로그램 종료");

	}

}
