package classes;

public class Student_04 {

	public static void main(String[] args) {
		
		// 기본 생성자로 객체를 생성하는 방법
		Student student1 = new Student();
		
		student1.hakbun = 2025001;
		student1.name = "홍길동";
		student1.major = "경제학과";
		student1.phone = "010-1111-1234";
		student1.addr = "경기도 고양시";
		
		student1.getStudentInfo();
		
		System.out.println();
		
		// 인자 생성자로 객체를 생성하는 방법
		Student student2 = 
				new Student(2025002, "세종대왕", "국문학과", "010-2222-2345", "서울시 중구");
		
		student2.getStudentInfo();
		
	}

}
