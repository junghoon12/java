package exam;

import java.util.Scanner;

public class Exam_05_01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("이름, 성별(male/ female), 나이를 입력하세요.....");
		
		// Person 객체 생성.
		Person person = new Person(sc.next(), sc.next(), sc.nextInt());
		
		System.out.println("============================");
		
		// 비지니스 로직
		person.getPersonInfo();
		
		sc.close();

	}

}
