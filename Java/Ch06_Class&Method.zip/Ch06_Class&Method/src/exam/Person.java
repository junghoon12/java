package exam;

public class Person {

	// 멤버변수
	String name;          // 이름
	String gender;        // 성별
	int age;              // 나이
	
	public Person() { }   // 기본 생성자
	
	public Person(String name, String gender, int age) {
		
		this.name = name;
		this.gender = gender;
		this.age = age;
		
	}   // 인자 생성자
	
	
	// 멤버 메서드
	void getPersonInfo() {
		
		System.out.println("이 름 : " + name);
		
		if(gender.equals("male")) {
			System.out.println("성 별 : 남자");
		}else {
			System.out.println("성 별 : 여자");
		}
		
		System.out.println("나 이 : " + age + "세");
		
	}  // getPersonInfo() 메서드 end
	
	
}
