package hi_class;

/*
 * [문제] 아래와 같은 내용을 콘솔 창에 출력해 보세요.
 *       단, 앞의 예제들에서 배운 내용을 활용하여 사용해 보세요.
 *       
 *       이 름 : 임 정 훈
 *       연락처 : 010-4725-3440
 *       이메일 : jhehun@gmail.com
 *       주 소 : 경기도 파주시
 */

public class Basic_04 {

	public static void main(String[] args) {
		
		System.out.print("이 름 : 임 정 훈");
		
		System.out.println("\n연락처 : 010-4725-3440");
		
		System.out.print("이메일 : jhehun@gmail.com\n");
		
		System.out.println("주 소 : 경기도 파주시");

	}

}
