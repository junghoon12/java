package exam;

// 다차원 배열의 가변 배열을 이용하자.

public class Exam_03_06 {

	public static void main(String[] args) {

		// 1. 다차원 배열의 가변 배열 선언 및 메모리 할당.
		int[][] step = new int[5][];   // 행 : 지정 / 열 : 미지정
		
		int count = 1;
		
		// 2. 가변 배열의 열을 메모리 할당.
		// step[0] = new int[1];    // 1행 1열
		// step[1] = new int[2];    // 2행 2열
		// step[2] = new int[3];    // 3행 3열
		// step[3] = new int[4];    // 4행 4열
		// step[4] = new int[5];    // 5행 5열
		
		for(int i=0; i<step.length; i++) {
			
			step[i] = new int[i+1];
			
		}
		
		// 3. 가변 배열에 데이터를 저장해 주자.
		for(int i=0; i<step.length; i++) {
			
			for(int j=0; j<step[i].length; j++) {
				
				step[i][j] = count++;
			}
		
		}
		
		// 4. 가변 배열에 저장된 데이터를 화면에 출력해 보자.
		for(int i=0; i<step.length; i++) {
			
			for(int j=0; j<step[i].length; j++) {
				
				System.out.print(step[i][j] + "\t");
			}
			
			System.out.println();
		
		}
		

	}

}
