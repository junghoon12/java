package exam;

import java.util.Scanner;

// 배열의 최대값과 최소값을 구하는 과제

public class Exam_03_01 {

	public static void main(String[] args) {
		
		// 1. 키보드로 데이터 입력 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 2. 배열의 크기를 키보드로 입력을 받자.
		System.out.print("정수 배열의 크기를 입력하세요. : ");
		
		// int size = sc.nextInt();
		
		int[] arr = new int[sc.nextInt()];
		
		// 3. 최대값, 최소값을 저장할 변수를 선언.
		int max = 0, min = 999;
		
		// 4. 배열에 키보드를 이용하여 임의의 정수를 입력을 받자.
		for(int i=0; i<arr.length; i++) {
			
			System.out.print((i+1) + "번째 정수 입력 : ");
			
			arr[i] = sc.nextInt();
			
			// 최대값을 구해 보자.
			if(arr[i] > max) {
				
				max = arr[i];
			}
			
			// 최소값도 구해 보자.
			if(arr[i] < min) {
				
				min = arr[i];
			}
		
		}
		
		System.out.println("최대값 >>> " + max);
		
		System.out.println("최소값 >>> " + min);
		
		sc.close();

	}

}
