package hi_class;

import java.io.IOException;
import java.io.InputStream;

/*
 * java 에서의 입출력 방식
 * - 스트림이라는 방식을 이용함.
 * - 스트림의 사전적 의미 : 시냇물이라는 뜻을 가지고 있음.
 *                     컴퓨터 공학에서의 스트림은 연속적인 데이터의 흐름,
 *                     또는 데이터를 전송하는 소프트웨어 모듈을 의미함.
 *                     시냇물에 띄어진 종이배가 순서대로 흘러가듯이, 컴퓨터
 *                     에서의 스트림은 도착한 순서대로 데이터를 흘려 보냄.
 * - java 에서의 스트림 : 순서가 있는 일련의 연속된 데이터.
 * - java 에서의 입출력 스트림은 응용프로그램과 입출력 장치를 연결하는
 *   소프트웨어 모듈임.
 *   응용 프로그램은 입력 스트림과 연결하며, 입력 스트림은 키보드 장치를
 *   제어하여 사용자의 키를 입력받아서 응용프로그램에게 전달함.
 *   또한 응용 프로그램은 출력 스트림에 연결하고 출력 스트림에 출력하면,
 *   출력 스트림은 다른 끝단에 연결된 출력 장치를 제어하여 출력을 완성함. 
 * - 스트림의 종류
 *   1) 바이트 스트림 : 1바이트 단위로 데이터를 입출력(byte).
 *   2) 문자 스트림 : 2바이트 단위로 데이터를 입출력(char).
 * - java 입출력 관련 클래스 : java.io 패키지에 존재함.
 *        ==> 해당 패키지에 있는 클래스들을 이용하여 파일을 
 *            입출력함.
 * - checked 방식의 예외 처리가 적용됨.
 * - java의 입출력은 단방향성 ==> 한쪽으로만 입력되고 출력이 됨.
 * - FIFO(First In First Out) : 먼저 입력되고 먼저 출력이 됨.  
 */

public class File_IO_01 {

	public static void main(String[] args) {
		
		System.out.println("한 문자를 입력하세요.....");
		
		// System.in : 표준입력장치(키보드)
		InputStream is = System.in;
		
		try {
			int readByte = is.read();
			
			System.out.println("읽어온 데이터(ASCII) >>> " + readByte);
			
			System.out.println("읽어온 데이터(문자) >>> " + (char)readByte);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
