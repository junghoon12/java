package hi_class;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

/*
 * 보조 스트림 관련 클래스
 * - 보조 스트림 : 다른 스트림과 연결되어 여러 가지 편리한
 *              기능을 제공해 주는 스트림을 말함.
 * - 파일을 읽거나 쓰기를 진행하게 되면 최종적으로 운영제체의
 *   API를 호출하여 파일에 쓰도록 시키고, 운영체제 API는 하드
 *   디스크에게 명령을 내려서 파일에 데이터를 기록을 하게 됨.
 *   이 때 자주 운영체제 API가 호출될수록 하드 디스크 장치나
 *   네트워크 장치가 자주 작동하게 되어 시스템의 효율은 나빠지고
 *   프로그램 역시 여러 번 입출력을 진행해야 하므로 입출력의
 *   실행 속도가 떨어지게 됨. 
 * - 보조 스트림은 중간에 메모리 버퍼(buffer)와 작업을
 *   함으로써 실행의 성능을 향상시킬 수 있음.
 *   예를 든다면 프로그램은 직접 하드 디스크에 데이터를 보내지
 *   않고, 메모리 버퍼에 데이터를 보냄으로써 쓰기 속도가 향상이 됨.
 *   버퍼는 데이터가 쌓이기만을 기다렸다가 버퍼가 꽉 차게 되면
 *   데이터를 한꺼번에 하드 디스크로 보내 줌으로써 출력 횟수를
 *   줄여주게 됨.
 * 
 * - 스트림의 기능(성능)을 향상시키는 클래스.
 * - Bufferedxxx : 버퍼를 제공해 주는 보조 스트림 관련 클래스.
 * - 버퍼(buffer) : CPU와 IO 간의 속도 차이를 보완해 주는 놈.
 * - flush() : 버퍼 스트림은 버퍼를 가지고 있기 때문에 버퍼가 
 *             꽉 찼을 때만 출력되는 특징이 있음. 그러므로 
 *             프로그램에서 데이터를 출력하였지만 버퍼에 다 차 
 *             있지 않아서 출력 장치에 보이지 않을 수 있음.
 *             버퍼가 다 차지 않은 상태에서 버퍼에 있는 데이터를 
 *             강제로 출력하는 장치에 보낼 때 사용하는 메서드.
 */


public class File_IO_07 {

	public static void main(String[] args) throws IOException {
		
		// 1. 바이트 스트림 방식으로 이미지 파일을 읽어 오자.
		
		FileInputStream fis = 
				new FileInputStream("D:/KDT_JAVA/test/koala.jpg");
		
		long start, end;
		
		start = System.nanoTime();
		
		while(fis.read() != -1) { }
		
		end = System.nanoTime();
		
		System.out.println("바이트 스트림을 이용한 경우 >>> " + (end - start) + "ns");
			
		fis.close();
		
		System.out.println();
		
		// 2. 바이트 스트림에 보조 스트림을 연결하여 이미지 파일을 읽어 오자.
		FileInputStream fis1 = 
				new FileInputStream("D:/KDT_JAVA/test/koala.jpg");
		
		BufferedInputStream bis = 
				new BufferedInputStream(fis1);
		
		start = System.nanoTime();
		
		while(bis.read() != -1) { }
		
		end = System.nanoTime();
		
		System.out.println("보조 스트림을 이용한 경우 >>> " + (end - start) + "ns");
			
		bis.close(); fis1.close();
	}

}
