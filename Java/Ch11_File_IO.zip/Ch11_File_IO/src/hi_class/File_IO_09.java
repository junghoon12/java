package hi_class;

/*
 * [문제] File_IO_05 예제 원본 소스 내용을 복사하여
 *       D:/KDT_JAVA/test/sample.txt 파일에
 *       출력해 주세요.
 */

public class File_IO_09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
