package hi_class;

import java.io.FileInputStream;
import java.io.InputStream;

public class File_IO_03 {

	public static void main(String[] args) {
		
		// 바이트 스트림 방식
		InputStream is = null;
		
		try {
			is = new FileInputStream("D:/KDT_JAVA/test/test.txt");
			
			while(true) {
				
				int readByte = is.read();
				
				// read() 메서드로 파일을 읽을 때 더 이상
				// 읽을 데이터가 없는 경우에는 -1 이라는 값을 반환함.
				if(readByte == -1) {
					
					break;
				}
				
				System.out.println("읽은 데이터 : " + (char)readByte + 
						", 남은 바이트 수 : " + is.available());
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
