package hi_class;

/*
 * [문제] for문을 이용하여 1 ~ 100 까지의 
 *       홀수의 합과 짝수의 합을 구하여 화면에 
 *       출력해 보세요.
 */

public class ForExam_27 {

	public static void main(String[] args) {
		
		int oddSum = 0, evenSum = 0;
		
		for(int su=1; su<=100; su++) {
			
			if(su % 2 == 1) {
				oddSum += su;
			}else {
				evenSum += su;
			}
		}
		
		System.out.println("1 ~ 100 까지의 홀수의 합 >>> " + oddSum);
		System.out.println("1 ~ 100 까지의 짝수의 합 >>> " + evenSum);

	}

}
