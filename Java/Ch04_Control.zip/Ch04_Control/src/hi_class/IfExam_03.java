package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로 정수 하나를 입력받아서 입력 받은 정수가
 *       5의 배수이면 "이 정수는 5의 배수입니다." 라는
 *       메세지를 화면에 출력해 보세요.
 */

public class IfExam_03 {

	public static void main(String[] args) {
		
		// 1. 키보드 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 2. 키보드로 정수 하나를 입력받아서 변수에 저장을 하자.
		System.out.print("정수 하나를 입력하세요. : ");
		
		int su = sc.nextInt();
		
		// 3. 조건식을 이용해서 5의 배수인지 판별을 하자.
		// int res = su % 5;
		
		if((su % 5) == 0) {  // true이면 5의 배수.
			// 4. 5의 배수이면 콘솔(화면)에 출력을 하자.
			System.out.println("이 정수는 5의 배수입니다.");
		}
		
		sc.close();

	}

}
