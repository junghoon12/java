package hi_class;

import java.util.Scanner;

public class SwitchCaseExam_14 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하나를 입력하세요. : ");
		
		int num = sc.nextInt();
		
		switch(num % 5) {
			case 0 :
				System.out.println("입력 받은 " + num + "은(는) 5의 배수입니다.");
				break;
			case 1 :
				System.out.println("입력 받은 " + num + "은(는) 5의 배수가 아닙니다. 나머지가 1입니다.");
				break;
			case 2 :
				System.out.println("입력 받은 " + num + "은(는) 5의 배수가 아닙니다. 나머지가 2입니다.");
				break;
			case 3 :
				System.out.println("입력 받은 " + num + "은(는) 5의 배수가 아닙니다. 나머지가 3입니다.");
				break;
			case 4 :
				System.out.println("입력 받은 " + num + "은(는) 5의 배수가 아닙니다. 나머지가 4입니다.");
				break;
		}
		
		sc.close();

	}

}
