package hi_class;

import java.util.Scanner;

/*
 * 1 ~ 100 사이의 정수 중에서 키보드로 5개의 정수를
 * 입력 받아서 5개의 정수 중에서 최대값을 화면에 출력해 보세요.
 * (예 : 1, 17, 65, 89, 26)
 */

public class WhileExam_23 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int max = 0, min = 100;     // 최대값이 저장될 변수
		
		int temp = 0, su = 1;
		
		while(su <= 5) {
			
			System.out.print(su + "번째 정수 입력 : ");
			
			temp = sc.nextInt();
			
			if(temp > max) {
				
				max = temp;
			}
			
			if(temp < min) {
				
				min = temp;
			}
			
			su++;
			
		}  // while 반복문 end
		
		System.out.println("최대값 >>> " + max);
		System.out.println("최소값 >>> " + min);
		
		sc.close();

	}

}
