package hi_class;

// while 반복문을 이용하여 1 ~ 10 까지의 합을 출력해 보자.

public class WhileExam_19 {

	public static void main(String[] args) {
		
		// 1. 변수 선언
		// 반복문에서 사용할 변수(초기식)와 1 ~ 10까지의 합을 저장할 변수.
		int su = 1, sum = 0;
		
		while(su <= 10) {
			
			sum += su;   // sum = sum + su;
			
			su++;
		}
		
		System.out.println("1 ~ 10 까지의 합 >>> " + sum);

	}

}
