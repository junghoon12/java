package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로부터 입력 받은 정수가
 *       홀수인지 아니면 짝수인지 판별하여
 *       화면에 출력해 보세요.
 */

public class IfElseExam_08 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 하나를 입력하세요. : ");
		
		int num = sc.nextInt();
		
		if(num % 2 == 1) {
			// true - 홀수인 경우
			System.out.println("입력 받은 " + num + "은(는) 홀수입니다.");
		}else {
			// false - 짝수인 경우
			System.out.println("입력 받은 " + num + "은(는) 짝수입니다.");
		}
		
		sc.close();

	}

}
