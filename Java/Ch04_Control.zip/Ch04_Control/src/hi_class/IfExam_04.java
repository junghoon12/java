package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로 입력 받은 정수 값이
         음수이면 "입력 받은 정수는 음수입니다."
         라는 메세지를 화면에 출력해 보세요.
 */

public class IfExam_04 {

	public static void main(String[] args) {
		
		// 1. 키보드 입력 위한 준비 작업
		Scanner sc = new Scanner(System.in);
		
		// 2. 키보드로부터 정수 하나를 입력받아서 변수에 저장.
		System.out.print("정수 하나를 입력하세요. : ");
		int num = sc.nextInt();
		
		// 3. 입력 받은 정수가 음수인지 조건을 체크하자.
		if(num < 0) {
			// 4. 입력 받은 정수가 음수이면 메세지를 화면에 출력.
			System.out.println("입력 받은 " + num + "은(는) 음수입니다.");
		}
		
		sc.close();

	}

}
