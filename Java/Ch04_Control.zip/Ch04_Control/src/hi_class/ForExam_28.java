package hi_class;

import java.util.Scanner;

/*
 * [문제] for문을 이용하여 키보드로 입력받은 수 까지의 
 *       홀수의 합과 짝수의 합을 구하여 화면에 
 *       출력해 보세요.
 */

public class ForExam_28 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수를 입력하세요. : ");
		
		int max = sc.nextInt();
		
		int oddSum = 0, evenSum = 0;
		
		for(int su=1; su<=max; su++) {
			
			if(su % 2 == 1) {
				oddSum += su;
			}else {
				evenSum += su;
			}
		}
		
		System.out.println("1 ~ " + max + "까지의 홀수의 합 >>> " + oddSum);
		System.out.println("1 ~ " + max + "까지의 짝수의 합 >>> " + evenSum);

		sc.close();
	}

}
