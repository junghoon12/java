package hi_class;

import java.util.Scanner;

public class SwitchCaseExam_15 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("알파벳 a ~ c 사이의 단어 중 한 글자 선택 : ");
		
		char str = sc.next().charAt(0);
		
		
		 switch(str) { 
		 	case 'a' :
		 		System.out.println("선택한 과일은 apple(사과) 입니다.");
		 		break;
		 	case 'b' : 
		 		System.out.println("선택한 과일은 banana(바나나) 입니다.");
		 		break;
		 	case 'c' : 
		 		System.out.println("선택한 과일은 cherry(체리) 입니다.");
		 		break;
		 	default :
		 		System.out.println("선택한 과일은 메뉴에 없는 과일입니다.");
		 }
		 
		 sc.close();

	}

}
