package hi_class;

import java.util.Scanner;

/*
 * [문제] 키보드로부터 점수를 입력받아서 입력 받은 점수가
 *       60점 이상이면 "합격", 60점 미만이면 "불합격"이라는 
 *       메세지를 화면에 출력해 보세요.
 */

public class IfElseExam_07 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("점수를 입력하세요. : ");
		
		int jumsu = sc.nextInt();
		
		if(jumsu >= 60) {
			// true - 60점 이상인 경우
			System.out.println("합격입니다.");
		}else {
			// false - 60점 미만인 경우
			System.out.println("불합격입니다.");
		}
		
		sc.close();

	}

}
