package hi_class;

// 다중 for문을 이용하여 구구단을 만들어 보자.

public class ForExam_31 {

	public static void main(String[] args) {

		for(int dan = 2; dan <= 9; dan++) {   // 구구단에서의 단
			
			System.out.println("*** "+ dan + "단 ***");
			
			for(int su = 1; su <= 9; su++) {
				
				System.out.println(dan + " * " + su + " = " + (dan * su));
			}
			
			System.out.println();
			
		}
		
		System.out.println();
		System.out.println();
		
		
		for(int su1 = 1; su1 <= 9; su1++) {           // 구구단에서의 수
			
			for(int dan1 = 2; dan1 <= 9; dan1++) {    // 구구단에서의 단
				
				System.out.print(dan1 + " * " + su1 + " = " + (dan1 * su1) + "\t");
			}
			
			System.out.println();
		}


	}

}
