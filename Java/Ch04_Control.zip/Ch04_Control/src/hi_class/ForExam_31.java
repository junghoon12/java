package hi_class;

// 다중 for문을 이용하여 구구단을 만들어 보자.

public class ForExam_31 {

	public static void main(String[] args) {

		for(int dan = 2; dan <= 9; dan++) {   // 구구단에서의 단
			
			System.out.println("*** "+ dan + "단 ***");
			
			for(int su = 1; su <= 9; su++) {
				
				System.out.println(dan + " * " + su + " = " + (dan * su));
			}
			
			System.out.println();
			
		}

	}

}
