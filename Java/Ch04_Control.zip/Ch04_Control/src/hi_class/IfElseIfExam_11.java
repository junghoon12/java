package hi_class;

import java.util.Scanner;

public class IfElseIfExam_11 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("알파벳 a ~ c 사이의 글자 중에서 한 글자 선택 . : ");
		
		String str = sc.next();
		
		if(str.equals("a")) {
			System.out.println("apple(사과)을 선택 하셨군요~~~");
		}else if(str.equals("b")) {
			System.out.println("banana(바나나)를 선택 하셨네요^^");
		}else if(str.equals("c")) {
			System.out.println("cherry(체리)를 선택 하셨습니다.");
		}else {
			System.out.println("메뉴에 없는 과일을 선택 하셨어요!!!");
		}
		
		sc.close();

	}

}
