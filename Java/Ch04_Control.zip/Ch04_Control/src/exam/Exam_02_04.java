package exam;

// 알파벳 출력하기

public class Exam_02_04 {

	public static void main(String[] args) {
		
		for(char c = 'Z'; c >= 'A'; c--) {
			
			for(char d = 'A'; d <= c; d++) {
				
				System.out.print(d);
			}
			
			System.out.println();
		}

	}

}
