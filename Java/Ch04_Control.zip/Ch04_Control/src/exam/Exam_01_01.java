package exam;

import java.util.Scanner;

// 4과목 성정 처리

public class Exam_01_01 {

	public static void main(String[] args) {

		// 1. 키보드로 입력 받기 위한 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 2-1. 키보드로 국어 점수를 입력을 받자.
		System.out.print("국어 점수 입력 : ");
		int kor = sc.nextInt();
		
		// 2-2. 키보드로 영어 점수를 입력을 받자.
		System.out.print("영어 점수 입력 : ");
		int eng = sc.nextInt();
		
		// 2-3. 키보드로 수학 점수를 입력을 받자.
		System.out.print("수학 점수 입력 : ");
		int mat = sc.nextInt();
		
		// 2-4. 키보드로 자바 점수를 입력을 받자.
		System.out.print("자바 점수 입력 : ");
		int java = sc.nextInt();
		
		// 3. 총점을 구하자.
		// 총점 = 국어점수 + 영어점수 + 수학점수 + 자바점수
		int total = kor + eng + mat + java;
		
		// 4. 평균을 구하자.
		// 평균 = 총점 / 과목 수
		double avg = total / 4.0;
		
		// 5. 성적 결과를 화면에 출력해 보자.
		System.out.println("국어점수 : " + kor + "점");
		System.out.println("영어점수 : " + eng + "점");
		System.out.println("수학점수 : " + mat + "점");
		System.out.println("자바점수 : " + java + "점");
		System.out.println("총   점 : " + total + "점");
		System.out.printf("평   균 : %.2f점\n", avg);
		
		sc.close();

	}

}
