package exam;

import java.util.Scanner;

public class Exam_02_01 {

	public static void main(String[] args) {
		
		// 1. 키보드로 데이터 입력 받을 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 2-1. 지방의 그램을 입력을 받자.
		System.out.print("지방의 그램을 입력하세요. : ");
		int fat = sc.nextInt();
		
		// 2-2. 탄수화물의 그램을 입력을 받자.
		System.out.print("탄수화물의 그램을 입력하세요. : ");
		int carbohydrate = sc.nextInt();
		
		// 2-3. 단백질의 그램을 입력을 받자.
		System.out.print("단백질의 그램을 입력하세요. : ");
		int protein = sc.nextInt();
		
		// 3. 총 칼로리를 구하자.
		// 총 칼로리 = (지방 * 9) + (단백질 * 4) + (탄수화물 * 4)
		int total = (fat * 9) + (protein * 4) + (carbohydrate * 4);
		
		// 4. 총 칼로리를 화면에 출력해 보자.
		System.out.printf("총칼로리 : %,dcal\n", total);
		
		sc.close();

	}

}
