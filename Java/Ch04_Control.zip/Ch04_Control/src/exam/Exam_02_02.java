package exam;

import java.util.Scanner;

public class Exam_02_02 {

	public static void main(String[] args) {
		
		// 1. 키보드로 데이터 입력 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 1-1. 홀수의 합 누적 변수와 짝수의 합 누적 변수를 만들자.
		int oddSum = 0, evenSum = 0;
		
		// 2. 키보드로 정수를 입력을 받자.
		System.out.print("수 입력 : ");
		
		int su = sc.nextInt();
		
		// 3. for 반목문을 이용하여 홀수, 짝수 변수에 누적을 시키자.
		for(int i=1; i<=su; i++) {
			
			if(i % 2 == 1) {
				oddSum += i;   // oddSum = oddSum + i;
			}else {
				evenSum += i;  // evenSum = evenSum + i;
			}
		}
		
		// 4. 화면에 홀수의 합과 짝수의 합을 출력하자.
		System.out.println("1 ~ " + su + " 까지의 홀수의 합 : " + oddSum);
		System.out.println("1 ~ " + su + " 까지의 짝수의 합 : " + evenSum);
		
		sc.close();

	}

}
