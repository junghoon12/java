package exam;

import java.util.Scanner;

public class Exam_01_04 {

	public static void main(String[] args) {
		
		// 1. 키보드로 4자리 수 입력 받을 준비 작업.
		Scanner sc = new Scanner(System.in);
		
		// 2. 4자리 정수를 입력을 받자.
		System.out.print("임의의 4자리 숫자 입력 : ");
		
		int num = sc.nextInt();
		
		// 3. 각각의 화폐단위 변수를 만들자.
		int money5000, money1000, money500, money100,
			money50, money10, money5, money1;
		
		// 4. 각각의 화폐 매수와 동전을 계산을 해 보자.
		// 예) 8762 입력 시
		// money5000 = num / 5000;   // 오천원의 몫 : 1
		// res = num % 5000;         // 오천원으로 나눈 나머지 : 3762
		
		// money1000 = res / 1000;   // 천원의 몫 : 3
		// res = res % 1000;         // 천원으로 나눈 나머지 : 762
		
		// money500 = res / 500;     // 오백원의 몫 : 1
		// res = res % 500;          // 오백원으로 나눈 나머지 : 262
		
		// money100 = res / 100;     // 백원의 몫 : 2
		// res = res % 100;          // 백원으로 나눈 나머지 : 62
		
		// money50 = res / 50;       // 오십원의 몫 : 1
		// res = res % 50;           // 오십원으로 나눈 나머지 : 12
		
		// money10 = res / 10;       // 십원의 몫 : 3
		// res = res % 10;           // 십원으로 나눈 나머지 : 2
		
		// money5 = res / 5;         // 오원의 몫 : 0
		// res = res % 5;            // 오원으로 나눈 나머지 : 2
		
		// money1 = res / 1;         // 일원의 몫 : 2
		// res = res % 1;            // 일원으로 나눈 나머지 : 0
		
		money5000 = num / 5000;
		
		money1000 = (num % 5000) / 1000;
		
		money500 = (num % 1000) / 500;
		
		money100 = (num % 500) / 100;
		
		money50 = (num % 100) / 50;
		
		money10 = (num % 50) / 10;
		
		money5 = (num % 10) / 5;
		
		money1 = (num % 5) / 1;
		
		// 5. 결과를 화면에 출력해 보자.
		System.out.println("입력 받은 숫자 >>> " + num);
		System.out.println("오천원 지폐 : " + money5000 + "장");
		System.out.println("천원 지폐 : " + money1000 + "장");
		System.out.println("오백원 동전 : " + money500 + "개");
		System.out.println("백원 동전 : " + money100 + "개");
		System.out.println("오십원 동전 : " + money50 + "개");
		System.out.println("십원 동전 : " + money10 + "개");
		System.out.println("오원 동전 : " + money5 + "개");
		System.out.println("일원 동전 : " + money1 + "개");
		
		sc.close();

	}

}
