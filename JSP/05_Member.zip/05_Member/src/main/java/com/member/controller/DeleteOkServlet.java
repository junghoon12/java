package com.member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/delete_ok.go")
public class DeleteOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 삭제 폼 페이지에서 넘어온 데이터들을 받아서
		// member 테이블에서 회원번호에 해당하는 회원을
		// 삭제하는 비지니스 로직.
		String member_pwd = request.getParameter("mem_pwd").trim();
		
		int member_no = 
			Integer.parseInt(request.getParameter("mem_no"));
		
		MemberDAO dao = new MemberDAO();
		
		// 데이터베이스에서 상세 정보를 가져오자.
		MemberDTO cont = dao.contentMember(member_no);
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if(member_pwd.equals(cont.getMempwd())) {
			
			int check = dao.deleteMember(member_no);
			
			if(check > 0) {
				
				dao.updateNum(member_no);
				
				out.println("<script>");
				out.println("alert('회원 삭제 성공!!!')");
				out.println("location.href='select.go'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('회원 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");	
			}
			
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀려요. 한 번 확인 요망~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
	}

}
