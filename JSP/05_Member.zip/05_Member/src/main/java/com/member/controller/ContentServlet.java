package com.member.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;


@WebServlet("/content.go")
public class ContentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public ContentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 회원의 이름을 클릭했을 때 get 방식으로 넘어온 회원번호에
		// 해당하는 회원의 정보를 조회하여 해당 정보를 view page로
		// 이동시키는 비지니스 로직.
		int member_no = Integer.parseInt(request.getParameter("num"));
		
		// 1단계 : 데이터베이스와 연동
		MemberDAO dao = new MemberDAO();
		
		// 2단계 : member 테이블에서 회원번호에 해당하는
		//        회원의 정보를 조회하는 메서드 호출.
		MemberDTO cont = dao.contentMember(member_no);
		
		request.setAttribute("Content", cont);
		
		// 3단계 : 페이지 이동을 진행하자.
		request.getRequestDispatcher("member_content.jsp").
				forward(request, response);
		
	}

}
