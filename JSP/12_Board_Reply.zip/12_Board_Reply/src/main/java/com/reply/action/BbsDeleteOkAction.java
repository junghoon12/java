package com.reply.action;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reply.model.BbsDAO;

public class BbsDeleteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 삭제 폼 페이지에서 넘어온 데이터들을 받아서
		// jsp_bbs 테이블에서 해당 게시글을 삭제하는 비지니스 로직.
		
		String bbs_pwd = request.getParameter("pwd").trim();
		
		int bbs_no = 
				Integer.parseInt(request.getParameter("bbs_no"));
		
		BbsDAO dao = BbsDAO.getInstance();
		
		
		
		return null;
	}

}
