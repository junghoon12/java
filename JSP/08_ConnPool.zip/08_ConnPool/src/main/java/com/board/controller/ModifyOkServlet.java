package com.board.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.model.BoardDAO;
import com.board.model.BoardDTO;


@WebServlet("/modify_ok.go")
public class ModifyOkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ModifyOkServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 수정 폼 페이지에서 넘어온 데이터들을 받아서
		// BOARD 테이블에 저장(수정)하는 비지니스 로직.
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 수정 폼 페이지에서 넘어온 데이터들을 받아주어야 한다.
		String board_writer = request.getParameter("writer").trim();
		
		String board_title = request.getParameter("title").trim();
		
		String board_content = request.getParameter("content").trim();
		
		String board_pwd = request.getParameter("pwd").trim();
		
		// type="hidden" 으로 넘어온 데이터들도 받아주어야 한다.
		int board_no = 
				Integer.parseInt(request.getParameter("board_no"));
		
		String db_pwd = request.getParameter("db_pwd");
		
		// 2단계 : DB에 전송할 DTO객체의 setter() 메서드에
		//        인자로 넘어온 데이터들을 넘겨 주자.
		BoardDTO dto = new BoardDTO();
		
		dto.setBoard_no(board_no);
		dto.setBoard_writer(board_writer);
		dto.setBoard_title(board_title);
		dto.setBoard_cont(board_content);
		dto.setBoard_pwd(board_pwd);
		
		BoardDAO dao = BoardDAO.getInstance();
		
		PrintWriter out = response.getWriter();
		
		if(board_pwd.equals(db_pwd)) {
			
			int chk = dao.updateBoard(dto);
			
			if(chk > 0) {
				
				out.println("<script>");
				out.println("alert('게시글 수정 성공!!!')");
				out.println("location.href='content.go?no="+board_no+"'");
				out.println("</script>");
			}else {
				
				out.println("<script>");
				out.println("alert('게시글 수정 실패~~~')");
				out.println("history.go(-1)");
				out.println("</script>");
			}
			
		}else {
			// 게시글 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인해 주세요~~~')");
			out.println("history.go(-1)");
			out.println("</script>");
		}
		
	}

}







