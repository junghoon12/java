package com.board.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.model.BoardDAO;

public class BoardDeleteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 삭제 폼 페이지에서 넘어온 글번호에 해당하는 게시글을
		// board 테이블에서 삭제하는 비지니스 로직.
		
		String board_pwd = request.getParameter("pwd").trim();
		
		int board_no = 
				Integer.parseInt(request.getParameter("board_no"));
		
		int nowPage = 
				Integer.parseInt(request.getParameter("page"));
		
		BoardDAO dao = BoardDAO.getInstance();
		
		int chk = dao.deleteBoard(board_no, board_pwd);
		
		PrintWriter out = response.getWriter();
		
		if(chk > 0) {
			
			dao.updateSequence(board_no);
			
			out.println("<script>");
			out.println("alert('게시글 삭제 성공!!!')");
			out.println("location.href='board_list.go?page="+nowPage+"'");
			out.println("</script>");
		}else if(chk == -1) {
			
			out.println("<script>");
			out.println("alert('비밀번호가 틀려요~~~')");
			out.println("history.back()");
			out.println("</script>");
		}else {
			
			out.println("<script>");
			out.println("alert('게시글 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		
		return null;
	}

}
