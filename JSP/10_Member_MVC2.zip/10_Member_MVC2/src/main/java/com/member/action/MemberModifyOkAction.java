package com.member.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.member.model.MemberDAO;
import com.member.model.MemberDTO;

public class MemberModifyOkAction implements Action {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 수정 폼 페이지에서 넘어온 데이터들을 받아서 member 테이블의
		// 회원번호에 해당하는 회원의 정보로 수정하는 비지니스 로직.
		
		String member_id = request.getParameter("mem_id").trim();

		String member_name = request.getParameter("mem_name").trim();
		
		String member_pwd = request.getParameter("mem_pwd").trim();
		
		int member_age =
				Integer.parseInt(request.getParameter("mem_age").trim());
		
		int member_mileage =
				Integer.parseInt(request.getParameter("mem_mileage").trim());
		
		String member_job = request.getParameter("mem_job").trim();
		
		String member_addr = request.getParameter("mem_addr").trim();
		
		// type="hidden" 으로 넘어온 데이터들도 받아주어야 한다.
		int member_no =
				Integer.parseInt(request.getParameter("mem_no").trim());
		
		String db_pwd = request.getParameter("db_pwd").trim();
		
		
		MemberDTO dto = new MemberDTO();
		
		dto.setMemno(member_no);
		dto.setMemid(member_id);
		dto.setMemname(member_name);
		dto.setMempwd(member_pwd);
		dto.setAge(member_age);
		dto.setMileage(member_mileage);
		dto.setJob(member_job);
		dto.setAddr(member_addr);
		
		MemberDAO dao = MemberDAO.getInstance();
		
		PrintWriter out = response.getWriter();
		
		if(member_pwd.equals(db_pwd)) {
			// 수정 폼 페이지에서 입력한 비밀번호와
			// member 테이블에 있는 회원 등록 시 입력한
			// 비밀번호가 일치하는 경우
			int chk = dao.updateMember(dto);
			
			if(chk > 0) {
				out.println("<script>");
				out.println("alert('회원 정보 수정 성공!!!')");
				out.println("location.href='member_content.go?num="+dto.getMemno()+"'");
				out.println("</script>");
				
			}else {
				out.println("<script>");
				out.println("alert('회원 정보 수정 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			// 비밀번호가 일치하지 않는 경우
			out.println("<script>");
			out.println("alert('비밀번호가 일치하지 않습니다. 확인해 주세요.~~~')");
			out.println("history.back()");
			out.println("</script>");
			
		}
		
		
		
		return null;
	}

}
