package com.emp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.emp.model.DeptDTO;
import com.emp.model.EmpDAO;
import com.emp.model.EmpDTO;


@WebServlet("/modify.go")
public class ModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ModifyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get 방식으로 넘어온 사원번호에 해당하는 사원의
		// 상세 정보를 view page(수정 폼 페이지)로 이동시키는 비지니스 로직.
		
		int emp_no = 
				Integer.parseInt(request.getParameter("no"));
		
		EmpDAO dao = EmpDAO.getInstance();
		
		// 담당업무에 대한 정보를 조회하는 메서드 호출.
		List<String> jobList = dao.getJobList();
		
		// 부서번호 리스트를 조회하는 메서드 호출.
		List<DeptDTO> deptList = dao.getDeptList();
		
		// 사원번호에 해당하는 사원의 상세정보를 조회하는 메서드 호출.
		EmpDTO cont = dao.contentEmp(emp_no);
		
		request.setAttribute("jList", jobList);
		
		request.setAttribute("dList", deptList);
		
		request.setAttribute("Modify", cont);
		
		request.getRequestDispatcher("emp_modify.jsp")
					.forward(request, response);
	}

}
