package com.emp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.emp.model.EmpDAO;
import com.emp.model.EmpDTO;


@WebServlet("/select.go")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 요청 : 전체 사원 목록을 보여달라고 요청.
		// 응답 : DB에 접속하여 emp 테이블에 있는 모든 사원 목록을
		//       가져와서 view page로 이동시키는 비지니스 로직.
		EmpDAO dao = EmpDAO.getInstance();
		
		System.out.println("전체 리스트 dao >>> " + dao);
		
		// 1단계 : DB의 EMP 테이블에서 전체 사원 리스트를 조회하는 메서드 호출.
		List<EmpDTO> empList = dao.getEmpList();
		
		// 2단계 : 모든 사원 목록을 view page로 이동.
		request.setAttribute("List", empList);
		
		request.getRequestDispatcher("emp_list.jsp").
					forward(request, response);
		
	}

}
