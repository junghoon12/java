package com.board.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class BoardDAO {

	// 멤버변수
	// 1. DB와 연동하는 객체.
	Connection con = null;
	
	// 2. DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	// BoardDAO 객체를 싱글톤 방식으로 만들어 보자.
	// 1단계 : 싱글톤 방식으로 객체를 만들기 위해서는 우선적으로
	//        기본 생성자의 접근제한을 private으로 선언해야 함.
	
	// 2단계 : BoardDAO 객체를 정적 멤버로 선언해야 함. - static으로 선언해야 함.
	private static BoardDAO instance = null;
	
	private BoardDAO() { }  // 기본 생성자
	
	// 3단계 : 기본 생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 라는 메서드를 만들어서 외부에서는
	//        해당 메서드로 접근할 수 있게 해 주면 됨.
	public static BoardDAO getInstance() {
		
		if(instance == null) {
			instance = new BoardDAO();
		}
		
		return instance;
		
	}  // getInstance() 메서드 end
	
	
	
	// DB와 연동하는 작업을 하는 메서드.
	public void openConn() {
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "web";
		
		String password = "2580";
		
		try {
			// 1단계 : 오라클 드라이버 메모리로 로딩
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 시도.
			con = DriverManager.getConnection(url, user, password);
			
			if(con != null) {
				System.out.println("데이터베이스 연결 성공!!!");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // openConn() 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(ResultSet rs, 
				PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(rs, pstmt, con) 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(PreparedStatement pstmt, 
					Connection con) {
		
		try {
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(pstmt, con) 메서드 end
	
	
	// board 테이블의 전체 게시물을 조회하는 메서드.
	public List<BoardDTO> getBoardList() {
		
		List<BoardDTO> list = new ArrayList<BoardDTO>();
		
		
		try {
			openConn();
			
			sql = "select * from board "
					+ " order by board_no desc";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				BoardDTO dto = new BoardDTO();
				
				dto.setBoard_no(rs.getInt("board_no"));
				dto.setBoard_writer(rs.getString("board_writer"));
				dto.setBoard_title(rs.getString("board_title"));
				dto.setBoard_cont(rs.getString("board_cont"));
				dto.setBoard_pwd(rs.getString("board_pwd"));
				dto.setBoard_hit(rs.getInt("board_hit"));
				dto.setBoard_date(rs.getString("board_date"));
				dto.setBoard_redate(rs.getString("board_redate"));
				
				list.add(dto);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getBoardList() 메서드 end
	
	
	
	// board 테이블에 게시글을 추가하는 메서드.
	public int insertBoard(BoardDTO dto) {
		
		int result = 0, count = 0;
		
		
		try {
			openConn();
			
			sql = "select max(board_no) from board";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				count = rs.getInt(1);
			}
			
			sql = "insert into board "
					+ " values(?, ?, ?, ?, ?, default, sysdate, '')";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, count + 1);
			pstmt.setString(2, dto.getBoard_writer());
			pstmt.setString(3, dto.getBoard_title());
			pstmt.setString(4, dto.getBoard_cont());
			pstmt.setString(5, dto.getBoard_pwd());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // insertBoard() 메서드 end
	
	
	// board 테이블에서 글번호에 해당하는 게시글의
	// 조회수를 증가시켜 주는 메서드.
	public void boardHit(int no) {
		
		
		try {
			openConn();
			
			sql = "update board set "
					+ " board_hit = board_hit + 1 "
					+ " where board_no = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
	}  // boardHit() 메서드 end
	
	
	// 글번호에 해당하는 게시글을 조회하는 메서드.
	public BoardDTO boardContent(int no) {
		
		BoardDTO dto = null;
		
		
		try {
			openConn();
			
			sql = "select * from board "
					+ " where board_no = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			rs = pstmt.executeQuery(); 
			
			if(rs.next()) {
				
				dto = new BoardDTO();
				
				dto.setBoard_no(rs.getInt("board_no"));
				dto.setBoard_writer(rs.getString("board_writer"));
				dto.setBoard_title(rs.getString("board_title"));
				dto.setBoard_cont(rs.getString("board_cont"));
				dto.setBoard_pwd(rs.getString("board_pwd"));
				dto.setBoard_hit(rs.getInt("board_hit"));
				dto.setBoard_date(rs.getString("board_date"));
				dto.setBoard_redate(rs.getString("board_redate"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return dto;
	}  // boardContent() 메서드 end
	
	
	// board 테이블에 글번호에 해당하는 게시글을 수정하는 메서드.
	public int updateBoard(BoardDTO dto) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "update board set board_title = ?,"
					+ " board_cont = ?, board_redate = sysdate "
					+ " where board_no = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, dto.getBoard_title());
			pstmt.setString(2, dto.getBoard_cont());
			pstmt.setInt(3, dto.getBoard_no());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
		return result;
	}  // updateBoard() 메서드 end
	
	
	// board 테이블에서 게시글 번호에 해당하는
	// 게시글을 삭제하는 메서드.
	public int deleteBoard(int no, String pwd) {
		
		int result = 0;
		
		
		try {
			openConn();
			
			sql = "select * from board where board_no = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				if(pwd.equals(rs.getString("board_pwd"))) {
					
					sql = "delete from board where board_no = ?";
					
					pstmt = con.prepareStatement(sql);
					
					pstmt.setInt(1, no);
					
					result = pstmt.executeUpdate();
					
				}else {
					// 비밀번호가 틀린 경우
					result = -1;
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // deleteBoard() 메서드 end
	
	
	// 게시글 삭제 시 글번호 재작업 하는 메서드.
	public void updateSequence(int no) {
		
		
		try {
			openConn();
			
			sql = "update board set "
					+ " board_no = board_no - 1 "
					+ " where board_no > ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(pstmt, con);
		}
		
	}  // updateSequence() 메서드 end
	
	
	// board 테이블에서 게시물을 검색하는 메서드.
	public List<BoardDTO> searchBoardList(
						String field, String keyword) {
		
		List<BoardDTO> searchList = new ArrayList<BoardDTO>();
		
		
		
		try {
			
			openConn();
			
			sql = "select * from board ";
			
			if(field.equals("title")) {
				
				sql += " where board_title like ? ";
				
			}else if(field.equals("cont")) {
				
				sql += " where board_cont like ? ";
				
			}else if(field.equals("writer")) {
				
				sql += " where board_writer like ? ";
			}
			
			sql += " order by board_no desc";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, "%"+keyword+"%");
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				BoardDTO dto = new BoardDTO();
				
				dto.setBoard_no(rs.getInt("board_no"));
				dto.setBoard_writer(rs.getString("board_writer"));
				dto.setBoard_title(rs.getString("board_title"));
				dto.setBoard_cont(rs.getString("board_cont"));
				dto.setBoard_pwd(rs.getString("board_pwd"));
				dto.setBoard_hit(rs.getInt("board_hit"));
				dto.setBoard_date(rs.getString("board_date"));
				dto.setBoard_redate(rs.getString("board_redate"));
				
				searchList.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return searchList;
	}  // searchBoardList() 메서드 end
	
	
	
	
	
	
	
	
	
		
}




