package com.himedia;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/join")
public class JoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public JoinServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// method="post" 방식인 경우
		// 요청 데이터에 한글이 있으면 한글이 깨지는 현상이 발생함. - 톰캣이 8 버전 이하
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : form 페이지에서 넘어온 데이터들을 받아 주어야 한다.
		String user_id = request.getParameter("id");
		String user_pwd = request.getParameter("pwd");
		String user_name = request.getParameter("name");
		String user_phone = request.getParameter("phone");
		String user_addr = request.getParameter("addr");
		String[] hobbys = request.getParameterValues("hobby");
		
		// 2단계 : 클라이언트에 요청한 결과를 응답해 주면 된다.
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head></head>");
		
		out.println("<body>");
		out.println("<h2>");
		out.println("아이디 : " + user_id + "<br>");
		out.println("비밀번호 : " + user_pwd + "<br>");
		out.println("이 름 : " + user_name + "<br>");
		out.println("연락처 : " + user_phone + "<br>");
		out.println("주 소 : " + user_addr + "<br>");
		out.println("취 미 : ");
		
		for(int i=0; i<hobbys.length; i++) {
			out.println(hobbys[i] + "&nbsp;&nbsp;&nbsp;");
		}
		
		out.println("</h2>");		
		out.println("</body>");
		
		out.println("</html>");
		
	}

}
