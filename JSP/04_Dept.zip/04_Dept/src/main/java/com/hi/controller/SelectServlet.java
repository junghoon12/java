package com.hi.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hi.model.DeptDAO;
import com.hi.model.DeptDTO;


@WebServlet("/select")
public class SelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SelectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 비니지스 로직
		// main.jsp 페이지에서 요청 ==> 전체 부서 목록을 보여달라고 요청
		// 해당 요청에 대해서 응답
		
		// 1단계 : DB와 연결 작업 진행.
		DeptDAO dao = new DeptDAO();
		
		// 2단계 : DB에서 dept 테이블의 전체 목록 조회하는 작업.
		List<DeptDTO> deptList = dao.selectList();
		
		System.out.println("list >>> " + deptList);
	}

}
