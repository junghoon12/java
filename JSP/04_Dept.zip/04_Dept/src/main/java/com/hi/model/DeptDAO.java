package com.hi.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/*
 * DAO(Data Access Object) : 데이터 접근 객체 ==> DB에 접속(연동)하는 객체.
 * - DAO란 데이터베이스에 접속해서 데이터 추가, 수정, 삭제, 조회 등의
 *   작업을 하는 클래스.
 * - 일반적으로 JSP 또는 Servlet에서 위의 작업들을 같이 할 수 있지만,
 *   유지보수, 코드의 모듈화 등을 위해서 DAO 클래스를 따로 만들어서 
 *   사용하는 것이 좋음.
 */

public class DeptDAO {
	
	// 멤버변수
	// 1. DB와 연동하는 객체.
	Connection con = null;
	
	// 2. DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	public DeptDAO() {
		
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		
		String user = "web";
		
		String password = "2580";
		
		
		
		try {
			// 1단계 : 오라클 드라이버 메모리로 로딩
			Class.forName(driver);
			
			// 2단계 : 오라클 데이터베이스와 연결 작업 시도.
			con = DriverManager.getConnection(url, user, password);
			
			if(con != null) {
				System.out.println("데이터베이스 연결 성공!!!");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // 기본 생성자
	
	
	// DEPT 테이블에서 전체 리스트를 조회하여 전체 리스트를 반환하는 메서드.
	public List<DeptDTO> selectList() {
		
		List<DeptDTO> list = new ArrayList<DeptDTO>();
		
		
		try {
			// 3단계 : 데이터베이스에 SQL문을 전송하기 위한 쿼리문 작성.
			sql = "select * from dept order by deptno";
			
			// 4단계 : SQL문을 데이터베이스 전송 객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			rs = pstmt.executeQuery();
			
			// 6단계 : 하나씩 데이터를 가져와서 DTO에 저장.
			while(rs.next()) {
				DeptDTO dto = new DeptDTO();
				
				dto.setDeptno(rs.getInt("deptno"));
				dto.setDname(rs.getString("dname"));
				dto.setLoc(rs.getString("loc"));
				
				list.add(dto);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return list;
	}  // selectList() 메서드 end
	
	
	// DEPT 테이블에 부서 정보를 저장하는 메서드.
	public int insertDept(DeptDTO dto) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "insert into dept values(?, ?, ?)";
			
			// 4단계 : SQL문을 데이터베이스 전송객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, dto.getDeptno());
			pstmt.setString(2, dto.getDname());
			pstmt.setString(3, dto.getLoc());
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			// SQL문이 select 쿼리문인 경우 executeQuery() 메서드를 실행.
			// SQL문이 insert, update, delete 쿼리문인 경우에는
			// executeUpdate() 메서드를 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}  // insertDept() 메서드 end
	
	
	// 부서번호에 부서를 DB에서 삭제하는 메서드.
	public int deleteDept(int no) {
		
		int result = 0;
		
		
		try {
			// 3단계 : 데이터베이스에 전송할 SQL문 작성.
			sql = "delete from dept where deptno = ?";
			
			// 4단계 : SQL문을 데이터베이스 전송객체에 저장.
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			// 5단계 : SQL문을 데이터베이스에 전송 및 실행.
			// SQL문이 select 쿼리문인 경우 executeQuery() 메서드를 실행.
			// SQL문이 insert, update, delete 쿼리문인 경우에는
			// executeUpdate() 메서드를 실행.
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return result;
	}  // deleteDept() 메서드 end
	

}
