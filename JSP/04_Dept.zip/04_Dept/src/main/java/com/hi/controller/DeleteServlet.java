package com.hi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hi.model.DeptDAO;


@WebServlet("/delete")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 삭제 버튼을 누르면 get 방식으로 넘어온 부서번호를
		// DEPT 테이블에서 삭제하는 비지니스 로직.
		
		response.setContentType("text/html; charset=UTF-8");
		
		// 1단계 : 삭제 버튼을 눌렀을 때 get 방식으로 넘어온 
		//        데이터를 받아 주어야 한다.
		int deptno = Integer.parseInt(request.getParameter("deptno").trim());
		
		// 2단계 : DB 연동하여 부서번호를 인자로 넘겨주면 됨.
		DeptDAO dao = new DeptDAO();
		
		int res = dao.deleteDept(deptno);
		
		PrintWriter out = response.getWriter();
		
		if(res > 0) {
			// 부서 삭제가 성공한 경우
			out.println("<script>");
			out.println("alert('부서 삭제 성공!!!')");
			out.println("location.href='select'");
			out.println("</script>");
		}else {
			// 부서 삭제가 실패한 경우
			out.println("<script>");
			out.println("alert('부서 삭제 실패~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
	}

}
