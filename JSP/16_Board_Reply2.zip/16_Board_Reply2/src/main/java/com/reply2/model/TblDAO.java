package com.reply2.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class TblDAO {

	// 멤버변수
	// 1. DB와 연동하는 객체.
	Connection con = null;
	
	// 2. DB에 SQL문을 전송하는 객체.
	PreparedStatement pstmt = null;
	
	// 3. SQL문을 실행한 후에 결과값을 가지고 있는 객체.
	ResultSet rs, rs1 = null;
	
	// 4. SQL 문을 저장할 문자열 객체.
	String sql = null;
	
	
	// TblDAO 객체를 싱글톤 방식으로 만들어 보자.
	// 1단계 : 싱글톤 방식으로 객체를 만들기 위해서는 우선적으로
	//        기본 생성자의 접근제한을 private으로 선언해야 함.
	
	// 2단계 : TblDAO 객체를 정적 멤버로 선언해야 함. - static으로 선언해야 함.
	private static TblDAO instance = null;
	
	private TblDAO() { }  // 기본 생성자
	
	// 3단계 : 기본 생성자 대신에 싱글턴 객체를 return 해 주는
	//        getInstance() 라는 메서드를 만들어서 외부에서는
	//        해당 메서드로 접근할 수 있게 해 주면 됨.
	public static TblDAO getInstance() {
		
		if(instance == null) {
			instance = new TblDAO();
		}
		
		return instance;
		
	}  // getInstance() 메서드 end
	
	
	
	// DB와 연동하는 작업을 하는 메서드. - DBCP 방식으로 연결 진행.
	public void openConn() {
		
		try {
			// 1단계 : JNDI 서버 객체 생성.
			Context ctx = new InitialContext();
			
			// 2단계 : lookup() 메서드를 이용하여 매칭되는 커넥션을 찾는다.
			DataSource ds = 
					(DataSource)ctx.lookup("java:comp/env/jdbc/myoracle");
			// 3단계 : DataSource 객체를 이용하여 커넥션 객체를 하나 가져온다.
			con = ds.getConnection();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}  // openConn() 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(ResultSet rs, 
				PreparedStatement pstmt, Connection con) {
		
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(rs, pstmt, con) 메서드 end
	
	
	// 자원을 종료시키는 메서드.
	public void closeConn(PreparedStatement pstmt, 
					Connection con) {
		
		try {
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}  // closeConn(pstmt, con) 메서드 end
	
	
	// tbl_board 테이블에 있는 전체 게시물 목록을 조회하는 메서드.
	public List<TblDTO> getBoardList() {
		
		List<TblDTO> list = new ArrayList<TblDTO>();
		
		
		try {
			openConn();
			
			sql = "select b.*, "
					+ " (select count(*) from tbl_reply r "
					+ "  where b.bno = r.bno) as cnt "
					+ "  from tbl_board b "
					+ "  order by b.bno desc";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				TblDTO dto = new TblDTO();
				
				dto.setBno(rs.getInt("bno"));
				dto.setWriter(rs.getString("writer"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setPwd(rs.getString("pwd"));
				dto.setRegdate(rs.getString("regdate"));
				dto.setRegupdate(rs.getString("regupdate"));
				dto.setRegCount(rs.getInt("cnt"));
				
				list.add(dto);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
						
			closeConn(rs, pstmt, con);
		}
		
		return list;
	}  // getBoardList() 메서드 end
	
	
	
	// tbl_board 테이블에서 게시글 번호에 해당하는 
	// 게시글의 상세정보를 조회하는 메서드.
	public TblDTO getBoardContent(int no) {
		
		TblDTO dto = null;
		
		
		try {
			openConn();
			
			sql = "select * from "
					+ " tbl_board where bno = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				dto = new TblDTO();
				
				dto.setBno(rs.getInt("bno"));
				dto.setWriter(rs.getString("writer"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setPwd(rs.getString("pwd"));
				dto.setRegdate(rs.getString("regdate"));
				dto.setRegupdate(rs.getString("regupdate"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return dto;
	}  // getBoardContent() 메서드 end
	
	
	// 원글번호에 해당하는 댓글 전체 목록을 조회하는 메서드.
	public String getReplyList(int no) {
		
		String str = "";
		
		
		try {
			openConn();
			
			sql = "select * from tbl_reply "
					+ " where bno = ? "
					+ " order by redate desc";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, no);
			
			rs = pstmt.executeQuery();
			
			str += "<replys>";
			
			while(rs.next()) {
				
				str += "<reply>";
				
				str += "<rno>" + rs.getInt("rno") + "</rno>";
				str += "<bno>" + rs.getInt("bno") + "</bno>";
				str += "<rewriter>" + rs.getString("rewriter") + "</rewriter>";
				str += "<recont>" + rs.getString("recont") + "</recont>";
				str += "<redate>" + rs.getString("redate") + "</redate>";
				str += "<reupdate>" + rs.getString("reupdate") + "</reupdate>";
				
				str += "</reply>";
			}
			
			str += "</replys>";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return str;
	}  // getReplyList() 메서드 end
	
	
	
	// 답변 내용을 tbl_reply 테이블에 저장하는 메서드.
	public int replyInsert(ReplyDTO dto) {
		
		int result = 0, count = 0;
		
		
		try {
			openConn();
			
			sql = "select max(rno) "
					+ " from tbl_reply";
			
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				count = rs.getInt(1);
			}
			
			sql = "insert into tbl_reply "
					+ " values(?, ?, ?, ?, sysdate, '')";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, count + 1);
			pstmt.setInt(2, dto.getBno());
			pstmt.setString(3, dto.getRewriter());
			pstmt.setString(4, dto.getRecont());
			
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			closeConn(rs, pstmt, con);
		}
		
		return result;
	}  // replyInsert() 메서드 end
	
	
	
	
	
	
	
	
}
