package com.upload.action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.upload.model.UploadDAO;
import com.upload.model.UploadDTO;

public class UploadDeleteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// 삭제 폼 페이지에서 넘어온 글번호와 비밀번호를 가지고
		// upload 테이블에서 게시글을 삭제하는 비지니스 로직.
		
		String upload_pwd = request.getParameter("pwd").trim();
		
		int upload_no =
				Integer.parseInt(request.getParameter("upload_no"));
		
		UploadDAO dao = UploadDAO.getInstance();
		
		UploadDTO cont = dao.uploadContent(upload_no);
		
		// 상세정보에서 업로드된 첨부파일을 가져옴.
		String fileName = cont.getUpload_file();
		
		// upload 폴더에 업로드된 첨부파일까지 삭제를 해 보자.
		String saveFolder = "D:\\KDT_JAVA\\workspace(jsp)\\13_Board_FileUpload\\src\\main\\webapp\\upload";
		
		PrintWriter out = response.getWriter();
		
		if(upload_pwd.equals(cont.getUpload_pwd())) {
			
			int chk = dao.deleteUpload(upload_no);
			
			// 게시글 삭제 후 첨부파일까지 삭제해 보자.
			if(fileName != null) {
				
				File file = new File(saveFolder+fileName);
				
				file.delete();  // 파일을 제거(삭제)하는 메서드.
				
			}
			
			if(chk > 0) {
				
				dao.updateSequence(upload_no);
				
				out.println("<script>");
				out.println("alert('자료실 게시판 게시글 삭제 성공!!!')");
				out.println("location.href='upload_list.go'");
				out.println("</script>");
			}else {
				out.println("<script>");
				out.println("alert('자료실 게시판 게시글 삭제 실패~~~')");
				out.println("history.back()");
				out.println("</script>");
			}
		}else {
			// 비밀번호가 틀린 경우
			out.println("<script>");
			out.println("alert('비밀번호가 틀립니다. 확인 요망~~~')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}

}
