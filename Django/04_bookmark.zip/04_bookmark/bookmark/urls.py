from django.urls import path
from . import views

urlpatterns = [

    path('', views.view, name="list"),
    path('add/', views.create_view, name="add"),
    path('<int:id>', views.detail_view, name="detail"),        # 상세 페이지 경로
    path('<int:pk>/edit/', views.update_view, name="edit"),    # 수정 페이지 경로
    path('<int:id>/delete', views.delete_view, name="delete"), # 삭제 페이지 경로
]