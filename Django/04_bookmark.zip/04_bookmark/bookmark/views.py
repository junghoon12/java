from django.shortcuts import render, redirect, get_object_or_404
from pip._internal import req

from bookmark.models import Bookmark


# Create your views here.
def view(request) :
    bookmark_list = Bookmark.objects.order_by('-id')
    # 북마크에 번호를 붙여서 재작업하는 방법
    total_count = bookmark_list.count()

    numbered_list = []

    for i, bookmark in enumerate(bookmark_list) :
        bookmark.number = total_count - i
        numbered_list.append(bookmark)

    context = {'booklist' : numbered_list}
    return render(request, 'bookmark/booarmark_list.html', context)


def create_view(request) :
    if request.method == 'POST' :
        name = request.POST.get('name')
        url = request.POST.get('url')

        if name and url :
            Bookmark.objects.create(site_name = name, url = url)
            return redirect('list')
    return render(request, 'bookmark/add.html')

def detail_view(request, id) :
    bookmark = get_object_or_404(Bookmark, pk=id)

    return render(request, 'bookmark/detail.html',
                  {'bookmark' : bookmark})


def update_view(request, pk) :
    bookmark = get_object_or_404(Bookmark, pk=pk)
    if request.method == 'POST' :
        site_name = request.POST.get('site_name')
        url = request.POST.get('url')
        if site_name and url :
            bookmark.site_name = site_name
            bookmark.url = url
            bookmark.save()
            return redirect('list')
    return render(request, 'bookmark/edit.html',
                  {'bookmark' : bookmark})


def delete_view(request, id) :
    bookmark = get_object_or_404(Bookmark, pk=id)

    if request.method == 'POST' :
        bookmark.delete()
        return redirect('list')
    return render(request, 'bookmark/delete.html',
                  {'bookmark' : bookmark})
