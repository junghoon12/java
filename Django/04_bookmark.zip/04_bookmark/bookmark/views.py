from django.shortcuts import render

from bookmark.models import Bookmark


# Create your views here.
def view(request) :
    bookmark_list = Bookmark.objects.all();
    context = {'booklist' : bookmark_list}
    return render(request, 'bookmark/booarmark_list.html', context)