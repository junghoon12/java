from django.contrib import admin

from bookmark.models import Bookmark

# Register your models here.
admin.site.register(Bookmark)