from django.contrib import admin

from shopmall.models import *


# Register your models here.
class CategoryAdmin(admin.ModelAdmin) :
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug' : ('name',)}

admin.site.register(Category, CategoryAdmin)

class ProductAdmin(admin.ModelAdmin) :
    list_display = ['id', 'name', 'category', 'quantity', 'price', 'available', 'created']
    list_filter = ['available', 'created', 'category']
    search_fields = ['name', 'description']
    prepopulated_fields = {'slug' : ('name',)}

admin.site.register(Product, ProductAdmin)

class CartAdmin(admin.ModelAdmin) :
    list_display = ['user', 'product', 'quantity', 'price', 'total', 'added_at']
    search_fields = ['user', 'product']

    def price(self, obj) :
        return obj.product.price

    def total(self, obj) :
        return obj.quantity * obj.product.price

    # 컬럼명을 보기 좋게 설정.
    total.short_description = '총액'
    price.short_description = '단가'

admin.site.register(CartItem, CartAdmin)