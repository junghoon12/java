from django.urls import path, re_path
from . import views
from django.conf import settings
from django.conf.urls.static import static

app_name = 'shopmall'

urlpatterns = [
    path('', views.product_list, name='product_list'),  # 전체 상품 목록 URL
    re_path(r'^category/(?P<category_slug>[\w가-힣-]+)/$', views.product_list, name='product_by_category'), # 카테고리별 상품 목록 URL
    path('product/<int:pk>/', views.product_detail, name="product_detail"),  # 상세 정보 URL
    path('cart/add/<int:pk>/', views.add_to_cart, name="add_to_cart"), # 장바구니 저장 URL
    path('cart/', views.cart_list, name="cart_list"),  # 장바구니 목록 URL
    path('product/<int:pk>/edit/', views.product_edit, name="product_edit"), # 상품 수정 URL
    path('product/<int:pk>/delete/', views.product_delete, name="product_delete"), # 상품 삭제 URL
]
