from django.contrib.auth.models import User
from django.db import models

# Create your models here.
class Category(models.Model) :
    name = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=200, db_index=True,
                     unique=True, allow_unicode=True)

    class Meta :
        ordering = ['name']
        verbose_name = '카테고리'
        verbose_name_plural = '카테고리 목록'

    def __str__(self) :
        return self.name


class Product(models.Model) :
    category = models.ForeignKey(
        Category, on_delete=models.CASCADE, related_name='products')
    name = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=200, db_index=True, allow_unicode=True)
    image = models.ImageField(upload_to='products/%Y/%m/%d/', blank=True)
    description = models.TextField(blank=True)
    quantity = models.PositiveIntegerField(default=0)
    price = models.DecimalField(max_digits=10, decimal_places=0)
    available = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta :
        ordering = ['-created']

    def __str__(self) :
        return self.name

class CartItem(models.Model) :
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta :
        unique_together = ('user', 'product')

    def __str__(self) :
        return f'{self.user.username} - {self.product.name} ({self.quantity})'