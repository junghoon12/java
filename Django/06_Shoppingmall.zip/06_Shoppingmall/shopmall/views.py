from django.shortcuts import render, get_object_or_404, redirect
from pip._internal import req

from shopmall.models import *


# Create your views here.
def product_list(request, category_slug=None) :
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)
    selected_category = None

    if category_slug :
        selected_category = get_object_or_404(Category, slug=category_slug)
        products = products.filter(category=selected_category)

    context = {
        'categories' : categories,
        'products' : products,
        'selected_category' : selected_category
    }

    return render(request, 'shopmall/product_list.html', context)


def product_detail(request, pk) :
    product = get_object_or_404(Product, pk=pk)

    return render(request, 'shopmall/product_detail.html', {'product' : product})


def add_to_cart(request, pk) :
    if request.method == 'POST' :
        product = get_object_or_404(Product, pk=pk)
        quantity = int(request.POST.get('quantity', 1))

        cart_item, created = CartItem.objects.get_or_create(
            user = request.user,
            product = product,
            defaults = {'quantity' : quantity}
        )

        if not created :
            cart_item.quantity += quantity
            cart_item.save()

        return redirect('shopmall:cart_list')


def cart_list(request) :
    cart_item = CartItem.objects.filter(user=request.user)
    cart_items = []
    total = 0

    for item in cart_item:
        item_total = item.product.price * item.quantity
        total += item_total
        cart_items.append({
            'name' : item.product.name,
            'price' : item.product.price,
            'quantity' : item.quantity,
            'image' : item.product.image.url,
            'total_price' : item_total,
        })

    return render(request, 'shopmall/cart_list.html',
                  {
                            'cart_items' : cart_items,
                            'total' : total,
    })


def product_edit(request, pk) :
    product = get_object_or_404(Product, pk=pk)

    if request.method == 'POST' :
       product.name = request.POST.get('name', product.name)
       product.description = request.POST.get('description', product.description)
       product.price = request.POST.get('price', product.price)
       product.available = 'available' in request.POST

       if 'image' in request.FILES :
           product.image = request.FILES['image']

       product.save()

       return redirect('shopmall:product_detail', pk=product.pk)

    # GET 요청 시엔 시에는 상세 정보를 폼에 보여주어야 함.
    context = { 'product' : product}

    return render(request, 'shopmall/product_edit.html', context)


def product_delete(request, pk) :
    product = get_object_or_404(Product, pk=pk)
    product.delete()
    return redirect('shopmall:product_list')
