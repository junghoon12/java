from datetime import timezone
from django.db import models
import datetime

# Create your models here.
class Question(models.Model) :
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField()

    def __str__(self) :
        return self.question_text

    # 게시된 시간이 24시간 이내에 게시가 되었는지를 판단하는 메서드.
    # 반환 타입은 Boolean 타입임. - True or False
    def was_published_recently(self) :
        return self.pub_date >= timezone.now() - datetime.timedelta(days=1)

class Choice(models.Model) :
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __str__(self) :
        return self.choice_text
