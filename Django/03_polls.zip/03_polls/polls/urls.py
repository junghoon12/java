from django.urls import path
from . import views

app_name = 'polls'

urlpatterns = [
    # 예) localhost:8000/polls
    path('', views.index, name='index'),
    # 예) localhost:8000/polls/3/
    path('<int:question_id>/detail', views.detail, name='detail'),
    # 예) localhost:8000/polls/3/results/
    path('<int:question_id>/results', views.results, name='results'),
    # 예) localhost:8000/polls/3/vote/
    path('<int:question_id>/votes', views.vote, name='vote')
]