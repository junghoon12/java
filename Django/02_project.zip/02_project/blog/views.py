from django.shortcuts import render
from .models import Post

# Create your views here.
def index(request) :
    posts = Post.objects.all().order_by('-pk')
    context = {'post': posts}

    return render(request, 'blog/index.html', context)


def detail_page(request, pk) :
    post = Post.objects.get(pk=pk)

    return render(request, 'blog/detail_page.html', {'post' : post})