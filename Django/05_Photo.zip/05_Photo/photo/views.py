from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponseForbidden
from django.shortcuts import render, redirect, get_object_or_404


from photo.models import Photo


# Create your views here.
def photo_list(request) :
    photos = Photo.objects.all()
    context = {'photos' : photos}

    return render(request, 'photo/photo_list.html', context)


def photo_upload(request) :

    if request.method == 'POST' :
        photo_file = request.FILES.get('photo')
        text = request.POST.get('text')

        if photo_file and text :
            Photo.objects.create(
                author = request.user,
                photo = photo_file,
                text = text
            )
            return redirect('list')

    return render(request, 'photo/photo_upload.html')


def photo_detail(request, id) :
    photo = get_object_or_404(Photo, pk=id)
    context = {'photo' : photo}

    return render(request, 'photo/photo_detail.html', context)


def photo_edit(request, id) :
    photo = get_object_or_404(Photo, pk=id)
    # 로그인 후 사진을 수정 시 체크해야 할 내용
    if request.user != photo.author : 
        return HttpResponseForbidden("수정 권한이 없습니다.")
    
    if request.method == 'POST' :
        photo.text = request.POST.get('text')
        if request.FILES.get('photo') :
            photo.photo = request.FILES['photo']
        photo.save()

        return redirect('photo_detail', id=photo.id)

    return render(request, 'photo/photo_edit.html', {'photo' : photo})


def photo_delete(request, pk) :
    photo = get_object_or_404(Photo, pk=pk)
    # 로그인 후 사진을 삭제 시 체크해야 할 내용
    if request.user != photo.author:
        return HttpResponseForbidden("삭제 권한이 없습니다.")

    if request.method == 'POST' :
        photo.delete()
        return redirect('list')

    return render(request, 'photo/photo_delete.html', {'photo' : photo})


def signup(request) :
    if request.method == 'POST' :
        form = UserCreationForm(request.POST)
        if form.is_valid() :
            user = form.save()
            login(request, user)
            return redirect('list')
    else :
        form = UserCreationForm()
    return render(request, 'photo/signup.html', {'form' : form})