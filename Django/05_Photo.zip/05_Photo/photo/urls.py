from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.photo_list, name="list"), # 전체 리스트 URL
    path('upload/', views.photo_upload, name="photo_upload"), # 파일 업로드 URL
    path('<int:id>/', views.photo_detail, name="photo_detail"), # 상세 페이지 URL
    path('<int:id>/edit/', views.photo_edit, name="photo_edit"), # 수정 페이지 URL
    path('<int:pk>/delete/', views.photo_delete, name="photo_delete"), # 삭제 페이지 URL
    path('signup/', views.signup, name="signup") # 회원 가입 페이지 URL
]
